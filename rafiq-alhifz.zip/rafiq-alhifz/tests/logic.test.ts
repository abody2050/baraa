import { describe, it, expect } from 'vitest';
import { analyze, countWords, countChars, tokenize, validateStandard, derive } from '../src/lib/text';
import { buildLayout } from '../src/lib/layout';
import { DEFAULT_STANDARD } from '../src/lib/defaults';
import { quranPageCount, validateQuranRange, sumBlocks } from '../src/lib/stats';
import { weekRange, addDays } from '../src/lib/dates';
import type { Block } from '../src/lib/types';

const BASE = ['الحمد', 'لله', 'رب', 'العالمين', 'الرحمن', 'الرحيم', 'مالك', 'يوم', 'الدين', 'إياك'];
const make = (n: number) => Array.from({ length: n }, (_, i) => BASE[i % BASE.length]).join(' ');
const S = DEFAULT_STANDARD;

describe('عد الكلمات', () => {
  it('1) نص فارغ أو مسافات فقط = صفر', () => {
    expect(countWords('')).toBe(0);
    expect(countWords('   \n\t  \n ')).toBe(0);
    expect(analyze('  \n ', S).words).toBe(0);
    expect(buildLayout('   ', S).faces.length).toBe(0);
  });
  it('2) سبحان الله! الشمس تسجد لله. = 5 (الجملة فعليًا خمس كلمات؛ الترقيم لا يُحتسب)', () => {
    expect(countWords('سبحان الله! الشمس تسجد لله.')).toBe(5);
  });
  it('3) مسافات كثيرة وأسطر فارغة', () => {
    expect(countWords('  سبحان    الله \n\n\n  الشمس\t\tتسجد   \n\n لله  ')).toBe(5);
  });
  it('4) نص مشكول بالكامل', () => {
    expect(countWords('وَمَا بِكُم مِّن نِّعْمَةٍ فَمِنَ اللَّهِ')).toBe(6);
  });
  it('4) التطويل لا يغيّر العدد', () => {
    expect(countWords('الـــحمـــد للــه')).toBe(2);
  });
  it('5) آيات وأرقام آيات وعلامات وقف', () => {
    expect(countWords('الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ ۝١ الرَّحْمَٰنِ الرَّحِيمِ ۝٢')).toBe(6);
    expect(countWords('الحمد لله ۖ رب العالمين ﴿١﴾ الرحمن')).toBe(5);
    expect(countWords('الحمد لله (1) رب')).toBe(3);
  });
  it('الكلمات المكررة تُحتسب', () => {
    expect(countWords('الله الله الله')).toBe(3);
  });
  it('علامات الترقيم بلا مسافات لا تدمج كلمتين', () => {
    expect(countWords('قال:الله،الرحمن—الرحيم')).toBe(4);
  });
  it('الترقيم المنفصل لا يُحتسب كلمة', () => {
    expect(countWords('قال - الله ، الرحمن ؟ !')).toBe(3);
  });
  it('الترقيم يبقى مع الكلمة في العرض', () => {
    expect(tokenize('سبحان الله! الشمس تسجد لله.')).toEqual(['سبحان', 'الله!', 'الشمس', 'تسجد', 'لله.']);
  });
  it('الأحرف تستثني التشكيل والترقيم والمسافات', () => {
    expect(countChars('سبحان الله!')).toBe(9);
  });
  it('الأرقام العادية داخل النص تُحتسب', () => {
    expect(countWords('حفظت 20 صفحة اليوم')).toBe(4);
  });
});

describe('الأوجه والمعيار', () => {
  it('6) 150 كلمة = وجه واحد', () => {
    const a = analyze(make(150), S);
    expect(a.words).toBe(150);
    expect(a.faces).toBe(1);
    expect(a.estLines).toBe(15);
  });
  it('7) 300 كلمة = وجهان', () => {
    expect(analyze(make(300), S).faces).toBe(2);
  });
  it('مثال 450 كلمة', () => {
    const a = analyze(make(450), S);
    expect(a.faces).toBe(3);
    expect(a.estLines).toBe(45);
    expect(a.juz).toBe(0.15);
  });
  it('16) تغيير المعيار يعيد الحساب دون تغيير النص', () => {
    const text = make(300);
    const before = text;
    const d = derive(300, { ...S, wordsPerFace: 100 });
    expect(d.faces).toBe(3);
    expect(text).toBe(before);
  });
  it('التحقق من المعيار', () => {
    expect(validateStandard(S).length).toBe(0);
    expect(validateStandard({ ...S, wordsPerFace: -5 }).length).toBeGreaterThan(0);
    expect(validateStandard({ ...S, minWordsPerLine: 14 }).length).toBeGreaterThan(0);
    expect(validateStandard({ ...S, linesPerFace: 0 }).length).toBeGreaterThan(0);
    expect(validateStandard({ ...S, targetWordsPerLine: 2.5 }).length).toBeGreaterThan(0);
  });
});

describe('توزيع الأسطر والأوجه', () => {
  it('12) نص طويل: أوجه من 15 سطرًا ووجه أخير جزئي بلا فقدان كلمات', () => {
    const n = 400;
    const text = make(n);
    const lay = buildLayout(text, S);
    const all = lay.faces.flatMap((f) => f.lineWords.flat());
    expect(all.length).toBe(n);
    expect(all.join(' ')).toBe(tokenize(text).join(' '));
    for (const f of lay.faces.slice(0, -1)) expect(f.lines.length).toBe(15);
    const last = lay.faces[lay.faces.length - 1];
    expect(last.partial).toBe(last.lines.length < 15);
    expect(lay.faces.length).toBe(Math.ceil(lay.totalLines / 15));
  });
  it('150 كلمة = وجه كامل من 15 سطرًا بـ 10 كلمات', () => {
    const lay = buildLayout(make(150), S);
    expect(lay.faces.length).toBe(1);
    expect(lay.faces[0].lines.length).toBe(15);
    expect(lay.faces[0].partial).toBe(false);
    expect(lay.faces[0].lineWords.every((l) => l.length === 10)).toBe(true);
    expect(lay.warnings.length).toBe(0);
  });
  it('300 كلمة = وجهان كاملان', () => {
    const lay = buildLayout(make(300), S);
    expect(lay.faces.length).toBe(2);
    expect(lay.faces.every((f) => !f.partial)).toBe(true);
  });
  it('الأسطر ضمن 8-12 كلمة لكل أطوال النص الكافية', () => {
    for (let n = 8; n <= 700; n += 7) {
      const lay = buildLayout(make(n), S);
      const total = lay.faces.reduce((a, f) => a + f.lineWords.flat().length, 0);
      expect(total).toBe(n);
      if (n >= 16) {
        for (const f of lay.faces) for (const l of f.lineWords) {
          expect(l.length).toBeGreaterThan(7);
          expect(l.length).toBeLessThan(13);
        }
      }
    }
  });
  it('نص قصير جدًا يعطي تنبيهًا ولا يحذف كلمات', () => {
    const lay = buildLayout(make(13), S);
    expect(lay.warnings.length).toBe(1);
    expect(lay.faces[0].lineWords.flat().length).toBe(13);
    expect(lay.faces[0].partial).toBe(true);
  });
  it('13) تغيير الخط لا يؤثر في بيانات التقسيم (مستقلة عن العرض)', () => {
    const a = buildLayout(make(200), S);
    const b = buildLayout(make(200), S);
    expect(JSON.stringify(a)).toBe(JSON.stringify(b));
  });
  it('علامات الترقيم محفوظة في الأسطر', () => {
    const text = 'سبحان الله! الشمس تسجد لله.';
    const lay = buildLayout(text, S);
    expect(lay.faces[0].lines.join(' ')).toBe(text);
  });
});

describe('القرآن والتواريخ', () => {
  it('17) عدد الصفحات = الأخيرة − الأولى + 1', () => {
    expect(quranPageCount(1, 5)).toBe(5);
    expect(quranPageCount(10, 10)).toBe(1);
    expect(validateQuranRange(5, 1, 604)).toBeTruthy();
    expect(validateQuranRange(1, 700, 604)).toBeTruthy();
    expect(validateQuranRange(0, 3, 604)).toBeTruthy();
    expect(validateQuranRange(1.5, 3, 604)).toBeTruthy();
    expect(validateQuranRange(1, 604, 604)).toBeNull();
  });
  it('بداية الأسبوع السبت', () => {
    // 2026-10-28 أربعاء
    expect(weekRange('2026-10-28', 6)).toEqual({ from: '2026-10-24', to: '2026-10-30' });
    expect(weekRange('2026-10-24', 6).from).toBe('2026-10-24');
    expect(weekRange('2026-10-28', 0)).toEqual({ from: '2026-10-25', to: '2026-10-31' });
    expect(addDays('2026-10-31', 1)).toBe('2026-11-01');
  });
  it('8) أربع كتل في يوم واحد: المجاميع صحيحة', () => {
    const mk = (id: string, words: number): Block => ({
      id, title: id, category: '', text: '', date: '2026-10-28', createdAt: 1, updatedAt: 1,
      words, chars: words * 4, lines: 0, faces: 0, notes: '', standard: S,
    });
    const t = sumBlocks([mk('a', 150), mk('b', 75), mk('c', 300), mk('d', 25)], S);
    expect(t.count).toBe(4);
    expect(t.words).toBe(550);
    expect(t.faces).toBe(3.67);
    expect(t.lines).toBe(55);
  });
});
