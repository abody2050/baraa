import 'fake-indexeddb/auto';
import { describe, it, expect, beforeEach } from 'vitest';
import { getAll, putItems, removeItem, clearStores, resetDbHandle } from '../src/lib/db';
import { sumBlocks } from '../src/lib/stats';
import { DEFAULT_STANDARD } from '../src/lib/defaults';
import { analyze } from '../src/lib/text';
import type { Block } from '../src/lib/types';

const mk = (id: string, text: string): Block => {
  const a = analyze(text, DEFAULT_STANDARD);
  return { id, title: id, category: '', text, date: '2026-10-28', createdAt: 1, updatedAt: 1, words: a.words, chars: a.chars, lines: a.estLines, faces: a.faces, notes: '', standard: DEFAULT_STANDARD };
};

describe('IndexedDB (fake-indexeddb)', () => {
  beforeEach(async () => { await clearStores(); });

  it('8) أربع كتل في يوم واحد تُحفظ وتُجمع', async () => {
    await putItems('blocks', [mk('1', 'أ ب ج'), mk('2', 'د هـ'), mk('3', 'و ز ح ط'), mk('4', 'ي')]);
    const all = await getAll<Block>('blocks');
    expect(all.length).toBe(4);
    expect(sumBlocks(all, DEFAULT_STANDARD).words).toBe(10);
  });
  it('9) إعادة فتح الاتصال تستعيد السجلات', async () => {
    await putItems('blocks', [mk('1', 'الحمد لله')]);
    resetDbHandle(); // يحاكي إغلاق الموقع وإعادة فتحه
    const all = await getAll<Block>('blocks');
    expect(all.length).toBe(1);
    expect(all[0].text).toBe('الحمد لله');
  });
  it('10) التعديل يستبدل الكتلة ولا يكررها', async () => {
    await putItems('blocks', [mk('1', 'كلمة واحدة')]);
    await putItems('blocks', [mk('1', 'كلمة واحدة اثنتان ثلاث')]);
    const all = await getAll<Block>('blocks');
    expect(all.length).toBe(1);
    expect(sumBlocks(all, DEFAULT_STANDARD).words).toBe(4);
  });
  it('11) الحذف يحدّث الإجماليات', async () => {
    await putItems('blocks', [mk('1', 'أ ب'), mk('2', 'ج د هـ')]);
    await removeItem('blocks', '1');
    const all = await getAll<Block>('blocks');
    expect(all.length).toBe(1);
    expect(sumBlocks(all, DEFAULT_STANDARD).words).toBe(3);
  });
});
