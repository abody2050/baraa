import { describe, it, expect } from 'vitest';
import { createBackup, validateBackup, mergeImport, toCsv, backupIsStale } from '../src/lib/backup';
import { DEFAULT_SETTINGS, DEFAULT_STANDARD } from '../src/lib/defaults';
import { analyze } from '../src/lib/text';
import type { Block, QuranEntry } from '../src/lib/types';

const mk = (id: string, text: string, date = '2026-10-28'): Block => {
  const a = analyze(text, DEFAULT_STANDARD);
  return { id, title: 't' + id, category: 'موعظة', text, date, createdAt: 1, updatedAt: 1, words: a.words, chars: a.chars, lines: a.estLines, faces: a.faces, notes: '', standard: DEFAULT_STANDARD };
};
const q: QuranEntry = { id: 'q1', fromPage: 1, toPage: 5, pages: 5, date: '2026-10-28', notes: '', createdAt: 1 };

describe('النسخ الاحتياطي', () => {
  it('15) التصدير ثم الاستيراد يحافظ على النصوص دون تكرار', () => {
    const blocks = [mk('a', 'سبحان الله! الشمس تسجد لله.'), mk('b', 'الحمد لله رب العالمين')];
    const file = JSON.parse(JSON.stringify(createBackup(DEFAULT_SETTINGS, blocks, [q])));
    const v = validateBackup(file);
    expect(v.ok).toBe(true);
    if (!v.ok) return;
    expect(v.data.blocks.map((b) => b.text)).toEqual(blocks.map((b) => b.text));
    const m1 = mergeImport([], [], v.data);
    expect(m1.addedBlocks).toBe(2);
    expect(m1.addedQuran).toBe(1);
    const m2 = mergeImport(m1.blocks, m1.quran, v.data);
    expect(m2.addedBlocks).toBe(0);
    expect(m2.skipped).toBe(3);
  });
  it('رفض ملفات تالفة', () => {
    expect(validateBackup(null).ok).toBe(false);
    expect(validateBackup({ app: 'x' }).ok).toBe(false);
    expect(validateBackup({ app: 'rafiq-alhifz', version: 1, blocks: [{ id: 1 }], quran: [] }).ok).toBe(false);
    expect(validateBackup({ app: 'rafiq-alhifz', version: 1, blocks: [], quran: [{ id: 'z', fromPage: 9, toPage: 2, date: '2026-01-01' }] }).ok).toBe(false);
    expect(validateBackup({ app: 'rafiq-alhifz', version: 1, blocks: [{ id: 'a', text: 'x', date: 'bad' }], quran: [] }).ok).toBe(false);
  });
  it('CSV يحمي من حقن المعادلات', () => {
    const b = mk('a', 'نص تجريبي');
    b.title = '=HYPERLINK("x")';
    const csv = toCsv([b], [], DEFAULT_STANDARD);
    expect(csv.includes(`"'=HYPERLINK(""x"")"`)).toBe(true);
  });
  it('تذكير النسخ الاحتياطي', () => {
    expect(backupIsStale(null, 14, true)).toBe(true);
    expect(backupIsStale(null, 14, false)).toBe(false);
    expect(backupIsStale(Date.now(), 14, true)).toBe(false);
    expect(backupIsStale(Date.now() - 20 * 86400000, 14, true)).toBe(true);
    expect(backupIsStale(null, 0, true)).toBe(false);
  });
});
