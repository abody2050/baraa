import { describe, it, expect } from 'vitest';
import { buildPdf } from '../src/lib/pdf';

describe('بناء ملف PDF', () => {
  it('14) بنية PDF صحيحة بعدد الصفحات المطلوب', () => {
    const fake = { data: new Uint8Array([0xff, 0xd8, 0xff, 0xd9]), w: 10, h: 10 };
    const bytes = buildPdf([fake, fake, fake]);
    const text = new TextDecoder('latin1').decode(bytes);
    expect(text.startsWith('%PDF-1.4')).toBe(true);
    expect(text.includes('/Count 3')).toBe(true);
    expect(text.trimEnd().endsWith('%%EOF')).toBe(true);
    const m = /startxref\n(\d+)/.exec(text);
    expect(m).toBeTruthy();
    expect(text.slice(Number(m![1]), Number(m![1]) + 4)).toBe('xref');
  });
});
