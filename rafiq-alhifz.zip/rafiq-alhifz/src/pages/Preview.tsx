import { useMemo, useState } from 'react';
import { useStore } from '../store';
import { buildLayout } from '../lib/layout';
import { readDraft } from '../components/AddBlockForm';
import { FacePage } from '../components/FacePage';
import { Card, Empty, PageHeader, toast } from '../components/ui';
import { buildPdf, downloadBytes, renderFace, type PageImage } from '../lib/pdf';
import { FONT_OPTIONS } from '../lib/defaults';

export function Preview({ id }: { id?: string }) {
  const { blocks, settings, updateSettings, ready } = useStore();
  const block = id ? blocks.find((b) => b.id === id) : undefined;
  const draft = useMemo(() => (id ? null : readDraft()), [id]);
  const text = block?.text ?? draft?.text ?? '';
  const title = block?.title || draft?.title || 'معاينة';
  const std = settings.standard;
  const layout = useMemo(() => buildLayout(text, std), [text, std]);
  const [cur, setCur] = useState(0);
  const [zoom, setZoom] = useState(1);
  const [showTools, setShowTools] = useState(false);
  const [range, setRange] = useState({ from: 1, to: 1 });
  const [busy, setBusy] = useState(false);
  const total = layout.faces.length;
  const idx = Math.min(cur, Math.max(0, total - 1));
  const continuous = settings.previewMode === 'continuous';
  const s = settings;

  if (id && ready && !block) return (<><PageHeader title="معاينة" back="/history" /><Empty title="لم نجد هذه الكتلة">ربما حُذفت. ارجع إلى سجل الحفظ.</Empty></>);
  if (total === 0) return (<><PageHeader title="معاينة الصفحات" back={id ? '/history' : '/'} /><Empty title="لا يوجد نص للمعاينة">الصق نصًا في صفحة الإضافة أولًا.</Empty></>);

  const exportPdf = async (from: number, to: number, label: string) => {
    if (busy) return;
    setBusy(true);
    try {
      const imgs: PageImage[] = [];
      for (let i = from - 1; i <= to - 1; i++) imgs.push(await renderFace(layout.faces[i], total, s));
      downloadBytes(buildPdf(imgs), `rafiq-${label}.pdf`);
      toast('تم إنشاء ملف PDF');
    } catch (e) {
      toast(e instanceof Error ? e.message : 'تعذر إنشاء PDF', 'err');
    } finally { setBusy(false); }
  };
  const r1 = Math.min(Math.max(1, range.from), total), r2 = Math.min(Math.max(r1, range.to), total);

  return (
    <>
      <PageHeader title={title} back={id ? '/block/' + id : '/'} actions={<button className="btn sm" onClick={() => setShowTools(!showTools)}>{showTools ? 'إخفاء الأدوات' : 'أدوات العرض'}</button>} />
      <p className="note no-print">{total} وجه · {layout.totalLines} سطرًا · {layout.totalWords} كلمة. كل سطر مُقسَّم مسبقًا ولا يتغير بتغيّر حجم النافذة.</p>
      {layout.warnings.map((w, i) => <p key={i} className="banner warn no-print">{w}</p>)}

      {showTools && (
        <Card title="أدوات العرض" className="no-print">
          <div className="grid2">
            <label className="field"><span>حجم الخط ({s.previewFontSize})</span><input type="range" min={12} max={40} value={s.previewFontSize} onChange={(e) => updateSettings({ previewFontSize: +e.target.value })} /></label>
            <label className="field"><span>ارتفاع السطر ({s.previewLineHeight})</span><input type="range" min={1.3} max={2.8} step={0.1} value={s.previewLineHeight} onChange={(e) => updateSettings({ previewLineHeight: +e.target.value })} /></label>
            <label className="field"><span>عرض الصفحة ({s.previewPageWidth})</span><input type="range" min={280} max={800} step={10} value={s.previewPageWidth} onChange={(e) => updateSettings({ previewPageWidth: +e.target.value })} /></label>
            <label className="field"><span>الهوامش ({s.previewMargin})</span><input type="range" min={8} max={80} value={s.previewMargin} onChange={(e) => updateSettings({ previewMargin: +e.target.value })} /></label>
            <label className="field"><span>نوع الخط</span><select value={s.previewFont} onChange={(e) => updateSettings({ previewFont: e.target.value })}>{FONT_OPTIONS.map((f) => <option key={f.label} value={f.value}>{f.label}</option>)}</select></label>
            <label className="field"><span>المحاذاة</span><select value={s.previewAlign} onChange={(e) => updateSettings({ previewAlign: e.target.value as typeof s.previewAlign })}><option value="justify">ضبط (مصحف)</option><option value="right">يمين</option><option value="center">وسط</option></select></label>
            <label className="field"><span>لون الخلفية</span><input type="color" value={s.previewBg} onChange={(e) => updateSettings({ previewBg: e.target.value })} /></label>
            <label className="field"><span>لون النص</span><input type="color" value={s.previewColor} onChange={(e) => updateSettings({ previewColor: e.target.value })} /></label>
            <label className="field"><span>العرض</span><select value={s.previewMode} onChange={(e) => updateSettings({ previewMode: e.target.value as typeof s.previewMode })}><option value="single">وجه واحد</option><option value="continuous">صفحات متتابعة</option></select></label>
          </div>
        </Card>
      )}

      <div className="row wrap center-row no-print">
        <button className="btn sm" onClick={() => setZoom((z) => Math.max(0.5, +(z - 0.1).toFixed(2)))} aria-label="تصغير">−</button>
        <span className="note">{Math.round(zoom * 100)}%</span>
        <button className="btn sm" onClick={() => setZoom((z) => Math.min(2, +(z + 0.1).toFixed(2)))} aria-label="تكبير">+</button>
      </div>

      <div className="faces print-area">
        {layout.faces.map((f, i) => (
          <FacePage key={f.number} face={f} total={total} settings={s} zoom={zoom} hiddenOnScreen={!continuous && i !== idx} />
        ))}
      </div>

      {!continuous && (
        <nav className="row center-row pager no-print" aria-label="التنقل بين الأوجه">
          <button className="btn" disabled={idx >= total - 1} onClick={() => { setCur(idx + 1); window.scrollTo({ top: 0 }); }}>الوجه التالي</button>
          <span className="pill">الوجه {idx + 1} من {total}</span>
          <button className="btn" disabled={idx <= 0} onClick={() => { setCur(idx - 1); window.scrollTo({ top: 0 }); }}>الوجه السابق</button>
        </nav>
      )}

      <Card title="تحميل PDF والطباعة" className="no-print">
        <div className="row wrap">
          <button className="btn primary" disabled={busy} onClick={() => exportPdf(1, total, 'all')}>{busy ? 'جارٍ الإنشاء…' : 'تحميل PDF (كل الأوجه)'}</button>
          <button className="btn" disabled={busy} onClick={() => exportPdf(idx + 1, idx + 1, `face-${idx + 1}`)}>الوجه الحالي</button>
          <button className="btn" onClick={() => window.print()}>طباعة</button>
        </div>
        <div className="row wrap" style={{ marginTop: 12 }}>
          <label className="field inline"><span>من وجه</span><input type="number" min={1} max={total} value={range.from} onChange={(e) => setRange({ ...range, from: +e.target.value })} /></label>
          <label className="field inline"><span>إلى وجه</span><input type="number" min={1} max={total} value={range.to} onChange={(e) => setRange({ ...range, to: +e.target.value })} /></label>
          <button className="btn" disabled={busy} onClick={() => exportPdf(r1, r2, `faces-${r1}-${r2}`)}>تصدير النطاق</button>
        </div>
        <p className="note">يُرسم كل وجه بخط جهازك ويُضمَّن في الملف كصورة، فتظهر الحروف متصلة وبالترتيب الصحيح دون مربعات.</p>
      </Card>
    </>
  );
}
