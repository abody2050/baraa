import { useState } from 'react';
import { useStore } from '../store';
import { addDays, formatShort, today, weekRange } from '../lib/dates';
import { combined, dailySeries, inRange, overview, quranTotals, sumBlocks } from '../lib/stats';
import { Bars, Card, Empty, EstimateNote, PageHeader, Stat, fmt, toast } from '../components/ui';
import { buildPdf, downloadBytes, renderReport } from '../lib/pdf';

export function Progress() {
  const { blocks, quran, settings, ready } = useStore();
  const [busy, setBusy] = useState(false);
  const std = settings.standard;
  const t = today();
  const ov = overview(blocks, std);
  const wk = weekRange(t, settings.weekStart);
  const thisWeek = sumBlocks(inRange(blocks, wk.from, wk.to), std);
  const prevFrom = addDays(wk.from, -7), prevTo = addDays(wk.from, -1);
  const prevBlocks = inRange(blocks, prevFrom, prevTo);
  const prevWeek = sumBlocks(prevBlocks, std);
  const s7 = dailySeries(blocks, t, 7).map((d) => ({ label: formatShort(d.date), value: d.words }));
  const s30 = dailySeries(blocks, t, 30).map((d) => ({ label: formatShort(d.date), value: d.words }));
  const qt = quranTotals(quran);
  const comb = combined(blocks, quran, std);
  const empty = blocks.length === 0 && quran.length === 0;

  let compare = 'لا توجد بيانات كافية للمقارنة مع الأسبوع السابق.';
  if (prevBlocks.length > 0) {
    const diff = thisWeek.words - prevWeek.words;
    compare = diff === 0 ? 'حفظك هذا الأسبوع مساوٍ للأسبوع السابق.' : diff > 0 ? `زاد حفظك ${fmt(diff)} كلمة عن الأسبوع السابق (≈ ${fmt(thisWeek.faces - prevWeek.faces)} وجه).` : `أقل من الأسبوع السابق بـ ${fmt(-diff)} كلمة (≈ ${fmt(prevWeek.faces - thisWeek.faces)} وجه).`;
  }

  const exportPdf = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const rows = [
        '# الإجماليات', `الكلمات: ${fmt(ov.totals.words)}`, `الأسطر التقديرية: ${fmt(ov.totals.lines)}`, `الأوجه التقديرية: ${fmt(ov.totals.faces)}`, `الأجزاء التقديرية: ${fmt(ov.totals.juz)}`,
        `أيام الحفظ النشطة: ${ov.activeDays}`, `متوسط الكلمات في اليوم النشط: ${fmt(ov.avgWordsPerActiveDay)}`, ov.bestDay ? `أفضل يوم: ${ov.bestDay.date} (${fmt(ov.bestDay.words)} كلمة)` : 'أفضل يوم: لا توجد بيانات', '',
        '# هذا الأسبوع مقابل السابق', `هذا الأسبوع: ${fmt(thisWeek.words)} كلمة`, `الأسبوع السابق: ${fmt(prevWeek.words)} كلمة`, compare, '',
        '# القرآن مقابل النصوص', `الأوجه المسجلة من القرآن مباشرة: ${fmt(comb.quranFaces)}`, `الأوجه التقديرية من النصوص: ${fmt(comb.textFaces)}`, `الإجمالي المركّب: ${fmt(comb.total)} (جمع بين طريقتين مختلفتين في القياس)`, '',
        'الأوجه والأجزاء قيم تقديرية ناتجة عن معيار الكلمات وليست مطابقة دقيقة لتوزيع الكلمات في المصحف.',
      ];
      downloadBytes(buildPdf(await renderReport('تقدمي في الحفظ — رفيق الحفظ', rows, settings)), 'rafiq-progress.pdf');
      toast('تم إنشاء ملف PDF');
    } catch (e) { toast(e instanceof Error ? e.message : 'تعذر إنشاء PDF', 'err'); }
    finally { setBusy(false); }
  };

  return (
    <>
      <PageHeader title="تقدمي في الحفظ" back={null} actions={<button className="btn sm" disabled={busy || empty} onClick={exportPdf}>{busy ? '…' : 'PDF'}</button>} />
      {ready && empty && <Empty title="لا توجد بيانات بعد">سجّل أول كتلة حفظ لتظهر هنا إحصائياتك الحقيقية.</Empty>}
      <Card title="الإجمالي">
        <div className="stats">
          <Stat label="كلمة" value={fmt(ov.totals.words)} accent />
          <Stat label="وجه تقديري" value={fmt(ov.totals.faces)} accent />
          <Stat label="سطر تقديري" value={fmt(ov.totals.lines)} />
          <Stat label="جزء تقديري" value={fmt(ov.totals.juz)} />
          <Stat label="أيام نشطة" value={fmt(ov.activeDays)} />
          <Stat label="متوسط الكلمات يوميًا" value={fmt(ov.avgWordsPerActiveDay)} hint="في الأيام النشطة" />
        </div>
        <p className="note">{ov.bestDay ? `أفضل يوم: ${ov.bestDay.date} بمقدار ${fmt(ov.bestDay.words)} كلمة.` : 'لم يُسجَّل أفضل يوم بعد.'}</p>
        <EstimateNote />
      </Card>
      <Card title="هذا الأسبوع والأسبوع السابق">
        <div className="stats">
          <Stat label="كلمة هذا الأسبوع" value={fmt(thisWeek.words)} hint={`≈ ${fmt(thisWeek.faces)} وجه`} accent />
          <Stat label="كلمة الأسبوع السابق" value={fmt(prevWeek.words)} hint={`≈ ${fmt(prevWeek.faces)} وجه`} />
        </div>
        <p className="note">{compare}</p>
      </Card>
      <Card title="آخر 7 أيام (كلمات)"><Bars data={s7} unit="كلمة" /></Card>
      <Card title="آخر 30 يومًا (كلمات)"><Bars data={s30} unit="كلمة" /></Card>
      <Card title="القرآن والنصوص">
        <div className="stats">
          <Stat label="وجه من القرآن (مباشر)" value={fmt(comb.quranFaces)} hint={`${qt.count} سجل`} />
          <Stat label="وجه تقديري من النصوص" value={fmt(comb.textFaces)} />
          <Stat label="الإجمالي المركّب" value={fmt(comb.total)} accent />
        </div>
        <p className="note">الإجمالي المركّب يجمع بين طريقتين مختلفتين في القياس: صفحات قرآنية مسجلة مباشرة، وأوجه تقديرية محسوبة من الكلمات. ولا نفترض أن صفحة المصحف تحتوي دائمًا العدد نفسه من الكلمات.</p>
      </Card>
    </>
  );
}
