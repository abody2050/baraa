import { useStore } from '../store';
import { derive } from '../lib/text';
import { formatLong } from '../lib/dates';
import { Card, Empty, EstimateNote, PageHeader, Stat, confirmAction, fmt, toast } from '../components/ui';
import { copyText } from '../components/BlockCard';
import { navigate } from '../router';

export function BlockDetail({ id }: { id: string }) {
  const { blocks, settings, deleteBlock, recalcBlock, ready } = useStore();
  const b = blocks.find((x) => x.id === id);
  if (!b) return (<><PageHeader title="تفاصيل الكتلة" back="/history" />{ready ? <Empty title="لم نجد هذه الكتلة">ربما حُذفت.</Empty> : <p className="note">جارٍ التحميل…</p>}</>);
  const d = derive(b.words, settings.standard);
  const s = b.standard;
  return (
    <>
      <PageHeader title={b.title} back="/history" />
      <Card>
        <p className="note">{b.category || 'بدون تصنيف'} · حُفظت بتاريخ {formatLong(b.date)}</p>
        <div className="stats">
          <Stat label="كلمة" value={fmt(b.words)} accent />
          <Stat label="وجه (المعيار الحالي)" value={fmt(d.faces)} accent />
          <Stat label="سطر تقديري" value={fmt(d.lines)} />
          <Stat label="جزء" value={fmt(d.juz)} />
          <Stat label="حرف" value={fmt(b.chars)} />
        </div>
        <p className="note">المعيار عند التسجيل: الوجه = {s.wordsPerFace} كلمة، السطر = {s.targetWordsPerLine} كلمات ({s.minWordsPerLine}–{s.maxWordsPerLine})، {s.linesPerFace} سطرًا في الوجه؛ فكانت النتيجة المسجَّلة ≈ {fmt(b.faces)} وجه.</p>
        <EstimateNote />
        {b.notes && <p><b>ملاحظات:</b> {b.notes}</p>}
        <div className="row wrap">
          <button className="btn primary" onClick={() => navigate('/preview/' + b.id)}>معاينة الصفحات</button>
          <button className="btn" onClick={() => navigate('/edit/' + b.id)}>تعديل</button>
          <button className="btn" onClick={async () => { try { await recalcBlock(b.id); toast('أُعيد الحساب'); } catch { toast('تعذرت إعادة الحساب', 'err'); } }}>إعادة الحساب</button>
          <button className="btn" onClick={() => copyText(b.text)}>نسخ النص</button>
          <button className="btn danger-outline" onClick={async () => { if (await confirmAction('حذف هذه الكتلة نهائيًا؟', 'حذف', true)) { try { await deleteBlock(b.id); toast('تم الحذف'); navigate('/history'); } catch { toast('تعذر الحذف', 'err'); } } }}>حذف</button>
        </div>
      </Card>
      <Card title="النص الأصلي">
        <div className="orig-text" dir="auto">{b.text}</div>
      </Card>
    </>
  );
}
