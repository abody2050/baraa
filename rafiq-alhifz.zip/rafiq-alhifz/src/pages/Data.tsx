import { useEffect, useRef, useState } from 'react';
import { useStore } from '../store';
import { createBackup, toCsv, validateBackup } from '../lib/backup';
import { estimateUsage } from '../lib/db';
import { downloadBlob } from '../lib/pdf';
import { Card, PageHeader, confirmAction, fmt, toast } from '../components/ui';
import { today } from '../lib/dates';

export function Data() {
  const { blocks, quran, settings, importBackup, deleteAll, markBackup, persisted } = useStore();
  const [usage, setUsage] = useState<{ usage: number | null; quota: number | null }>({ usage: null, quota: null });
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  useEffect(() => { estimateUsage().then(setUsage); }, [blocks.length, quran.length]);

  const dataBytes = new Blob([JSON.stringify({ blocks, quran })]).size;
  const kb = (n: number) => (n > 1048576 ? fmt(+(n / 1048576).toFixed(2)) + ' م.ب' : fmt(+(n / 1024).toFixed(1)) + ' ك.ب');

  const exportJson = () => {
    try {
      const file = createBackup(settings, blocks, quran);
      downloadBlob(new Blob([JSON.stringify(file, null, 2)], { type: 'application/json' }), `rafiq-backup-${today()}.json`);
      markBackup();
      toast('تم تنزيل النسخة الاحتياطية');
    } catch { toast('تعذر إنشاء النسخة الاحتياطية', 'err'); }
  };
  const exportCsv = () => {
    downloadBlob(new Blob([toCsv(blocks, quran, settings.standard)], { type: 'text/csv;charset=utf-8' }), `rafiq-log-${today()}.csv`);
    toast('تم تنزيل ملف CSV');
  };
  const onFile = async (file: File | undefined) => {
    if (!file || busy) return;
    setBusy(true);
    try {
      let json: unknown;
      try { json = JSON.parse(await file.text()); } catch { toast('الملف ليس بصيغة JSON صحيحة.', 'err'); return; }
      const v = validateBackup(json, settings.quranPages > 2000 ? settings.quranPages : 2000);
      if (!v.ok) { toast(v.error, 'err'); return; }
      if (!(await confirmAction(`ستُضاف ${v.data.blocks.length} كتلة و${v.data.quran.length} سجل قرآني من الملف (دون تكرار ما هو موجود). متابعة؟`, 'استيراد'))) return;
      const r = await importBackup(v.data);
      toast(`أُضيف ${r.addedBlocks + r.addedQuran} سجل، وتُجوهل ${r.skipped} مكرر`);
    } catch (e) { toast(e instanceof Error ? e.message : 'تعذر الاستيراد', 'err'); }
    finally { setBusy(false); if (fileRef.current) fileRef.current.value = ''; }
  };
  const wipe = async () => {
    if (!(await confirmAction('سيُحذف كل سجل الحفظ (الكتل والحفظ القرآني) نهائيًا من هذا الجهاز. هل نزّلت نسخة احتياطية؟', 'متابعة', true))) return;
    if (!(await confirmAction('تأكيد أخير: حذف جميع البيانات ولا يمكن التراجع؟', 'احذف كل شيء', true))) return;
    try { await deleteAll(); toast('تم حذف جميع البيانات'); } catch { toast('تعذر الحذف', 'err'); }
  };

  return (
    <>
      <PageHeader title="النسخ الاحتياطي وإدارة البيانات" back="/settings" />
      <Card title="حالة البيانات">
        <p className="note">كل بياناتك محفوظة في متصفح هذا الجهاز فقط ولا تُرسل إلى أي خادم. قد يؤدي مسح بيانات المتصفح أو حذف الموقع إلى فقدانها، لذلك نزّل نسخة احتياطية بانتظام.</p>
        <ul className="plain">
          <li>الكتل: {fmt(blocks.length)} · السجلات القرآنية: {fmt(quran.length)}</li>
          <li>حجم البيانات التقريبي: {kb(dataBytes)}{usage.usage !== null && usage.quota !== null ? ` (المستخدم من التخزين الكلي للموقع: ${kb(usage.usage)} من ${kb(usage.quota)})` : ''}</li>
          <li>التخزين الدائم: {persisted ? 'مفعّل (المتصفح لن يمسح بياناتك تلقائيًا)' : 'غير مضمون (قد يمسح المتصفح البيانات عند امتلاء المساحة). النسخ الاحتياطي مهم.'}</li>
          <li>آخر نسخة احتياطية: {settings.lastBackup ? new Date(settings.lastBackup).toLocaleString('ar-u-nu-latn') : 'لم تُنشأ بعد'}</li>
        </ul>
      </Card>
      <Card title="النسخ الاحتياطي">
        <div className="row wrap">
          <button className="btn primary" onClick={exportJson} disabled={!blocks.length && !quran.length}>تنزيل نسخة احتياطية (JSON)</button>
          <button className="btn" onClick={exportCsv} disabled={!blocks.length && !quran.length}>تصدير السجل (CSV)</button>
        </div>
        <label className="field"><span>استيراد نسخة احتياطية</span><input ref={fileRef} type="file" accept="application/json,.json" disabled={busy} onChange={(e) => onFile(e.target.files?.[0])} /></label>
        <p className="note">يُتحقق من الملف قبل الاستيراد، ولا تتكرر السجلات الموجودة.</p>
      </Card>
      <Card title="منطقة الخطر">
        <button className="btn danger" onClick={wipe} disabled={!blocks.length && !quran.length}>حذف جميع البيانات</button>
      </Card>
    </>
  );
}
