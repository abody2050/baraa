import { useMemo, useState } from 'react';
import { useStore } from '../store';
import { CATEGORIES } from '../lib/defaults';
import { formatLong, monthRange, today, weekRange } from '../lib/dates';
import { groupByDate, inRange, sumBlocks } from '../lib/stats';
import { Card, Empty, EstimateNote, PageHeader, confirmAction, fmt, toast } from '../components/ui';
import { BlockCard } from '../components/BlockCard';
import { buildPdf, downloadBytes, renderReport } from '../lib/pdf';

type Range = 'today' | 'week' | 'month' | 'all' | 'date';
const LABELS: Record<Range, string> = { today: 'اليوم', week: 'هذا الأسبوع', month: 'هذا الشهر', all: 'الكل', date: 'تاريخ محدد' };

export function History() {
  const { blocks, quran, settings, deleteQuran, ready } = useStore();
  const [range, setRange] = useState<Range>('today');
  const [pick, setPick] = useState(today());
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('');
  const [newestFirst, setNewestFirst] = useState(true);
  const [busy, setBusy] = useState(false);
  const std = settings.standard;
  const t = today();

  const bounds = useMemo(() => {
    if (range === 'today') return { from: t, to: t };
    if (range === 'week') return weekRange(t, settings.weekStart);
    if (range === 'month') return monthRange(t);
    if (range === 'date') return { from: pick, to: pick };
    return { from: '0000-01-01', to: '9999-12-31' };
  }, [range, pick, t, settings.weekStart]);

  const filtered = useMemo(() => {
    const term = q.trim();
    return inRange(blocks, bounds.from, bounds.to).filter((b) => (!term || b.title.includes(term)) && (!cat || b.category === cat));
  }, [blocks, bounds, q, cat]);
  const quranIn = useMemo(() => inRange(quran, bounds.from, bounds.to), [quran, bounds]);

  const days = useMemo(() => {
    const g = groupByDate(filtered);
    const keys = Array.from(g.keys()).sort();
    if (newestFirst) keys.reverse();
    return keys.map((d) => ({ date: d, list: g.get(d)!.sort((a, b) => (newestFirst ? b.createdAt - a.createdAt : a.createdAt - b.createdAt)) }));
  }, [filtered, newestFirst]);

  const total = sumBlocks(filtered, std);

  const exportPdf = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const rows: string[] = [`النطاق: ${LABELS[range]}`, `الإجمالي: ${fmt(total.words)} كلمة ≈ ${fmt(total.lines)} سطرًا ≈ ${fmt(total.faces)} وجهًا ≈ ${fmt(total.juz)} جزءًا (تقديري)`, ''];
      for (const d of days) {
        const s = sumBlocks(d.list, std);
        rows.push(`# ${formatLong(d.date)}`);
        rows.push(`${fmt(s.words)} كلمة · ${fmt(s.lines)} سطرًا · ${fmt(s.faces)} وجهًا · ${s.count} كتلة`);
        for (const b of d.list) rows.push(`- ${b.title}${b.category ? ' (' + b.category + ')' : ''}: ${fmt(b.words)} كلمة`);
        rows.push('');
      }
      if (quranIn.length) {
        rows.push('# الحفظ القرآني (منفصل عن النصوص)');
        for (const e of quranIn) rows.push(`- ${e.date}: من صفحة ${e.fromPage} إلى ${e.toPage} (${e.pages} صفحة)`);
      }
      rows.push('', 'الأوجه والأسطر والأجزاء قيم تقديرية وفق معيار الكلمات.');
      const imgs = await renderReport('سجل الحفظ — رفيق الحفظ', rows, settings);
      downloadBytes(buildPdf(imgs), 'rafiq-history.pdf');
      toast('تم إنشاء ملف PDF');
    } catch (e) { toast(e instanceof Error ? e.message : 'تعذر إنشاء PDF', 'err'); }
    finally { setBusy(false); }
  };

  return (
    <>
      <PageHeader title="سجل الحفظ" back={null} actions={<button className="btn sm" disabled={busy || (!filtered.length && !quranIn.length)} onClick={exportPdf}>{busy ? '…' : 'PDF'}</button>} />
      <div className="tabs" role="tablist">
        {(Object.keys(LABELS) as Range[]).map((r) => (
          <button key={r} role="tab" aria-selected={range === r} className={'tab' + (range === r ? ' on' : '')} onClick={() => setRange(r)}>{LABELS[r]}</button>
        ))}
      </div>
      {range === 'date' && <label className="field"><span>اختر التاريخ</span><input type="date" value={pick} onChange={(e) => setPick(e.target.value || today())} /></label>}
      <div className="grid2">
        <label className="field"><span>بحث باسم الكتلة</span><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="ابحث…" /></label>
        <label className="field"><span>نوع المادة</span><select value={cat} onChange={(e) => setCat(e.target.value)}><option value="">الكل</option>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></label>
      </div>
      <div className="row"><button className="btn sm" onClick={() => setNewestFirst(!newestFirst)}>الترتيب: {newestFirst ? 'من الأحدث إلى الأقدم' : 'من الأقدم إلى الأحدث'}</button></div>

      <Card title={`إجمالي ${LABELS[range]}`}>
        <div className="stats">
          <div className="stat"><div className="stat-value">{fmt(total.words)}</div><div className="stat-label">كلمة</div></div>
          <div className="stat"><div className="stat-value">{fmt(total.lines)}</div><div className="stat-label">سطر تقديري</div></div>
          <div className="stat"><div className="stat-value">{fmt(total.faces)}</div><div className="stat-label">وجه تقديري</div></div>
          <div className="stat"><div className="stat-value">{fmt(total.juz)}</div><div className="stat-label">جزء تقديري</div></div>
          <div className="stat"><div className="stat-value">{fmt(total.count)}</div><div className="stat-label">كتلة</div></div>
        </div>
        <EstimateNote />
      </Card>

      {!ready && <p className="note">جارٍ التحميل…</p>}
      {ready && days.length === 0 && quranIn.length === 0 && (
        <Empty title="لا توجد سجلات في هذا النطاق">{blocks.length === 0 ? 'لم تسجّل أي كتلة بعد. ابدأ من الصفحة الرئيسية.' : 'جرّب نطاقًا آخر أو امسح البحث.'}</Empty>
      )}
      {days.map((d) => {
        const s = sumBlocks(d.list, std);
        return (
          <section key={d.date} className="day">
            <h2 className="section-title">{formatLong(d.date)}</h2>
            <p className="note">{fmt(s.words)} كلمة · ≈ {fmt(s.lines)} سطرًا · ≈ {fmt(s.faces)} وجهًا · ≈ {fmt(s.juz)} جزءًا · {s.count} كتلة</p>
            <div className="stack">{d.list.map((b) => <BlockCard key={b.id} b={b} />)}</div>
          </section>
        );
      })}
      {quranIn.length > 0 && (
        <section className="day">
          <h2 className="section-title">الحفظ القرآني (مسجَّل بالصفحات، منفصل عن النصوص)</h2>
          <div className="stack">
            {[...quranIn].sort((a, b) => b.date.localeCompare(a.date)).map((e) => (
              <article key={e.id} className="block-card">
                <div className="block-top"><b>من صفحة {e.fromPage} إلى {e.toPage}</b><span className="chip">{e.pages} وجه</span></div>
                <div className="block-meta"><span>{e.date}</span>{e.notes && <span>{e.notes}</span>}</div>
                <div className="block-actions"><button className="btn sm danger-outline" onClick={async () => { if (await confirmAction('حذف هذا السجل القرآني؟', 'حذف', true)) { try { await deleteQuran(e.id); toast('تم الحذف'); } catch { toast('تعذر الحذف', 'err'); } } }}>حذف</button></div>
              </article>
            ))}
          </div>
        </section>
      )}
    </>
  );
}
