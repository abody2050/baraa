import { useEffect, useMemo, useState } from 'react';
import { useStore } from '../store';
import { analyze } from '../lib/text';
import { CATEGORIES } from '../lib/defaults';
import { today } from '../lib/dates';
import { navigate } from '../router';
import { Card, Empty, PageHeader, toast } from '../components/ui';
import { ResultCards } from '../components/ResultCards';

export function EditBlock({ id }: { id: string }) {
  const { blocks, settings, saveBlock, ready } = useStore();
  const b = blocks.find((x) => x.id === id);
  const [f, setF] = useState<{ title: string; category: string; text: string; date: string; notes: string } | null>(null);
  const [busy, setBusy] = useState(false);
  useEffect(() => { if (b && !f) setF({ title: b.title, category: b.category, text: b.text, date: b.date, notes: b.notes }); }, [b, f]);
  const result = useMemo(() => (f ? analyze(f.text, settings.standard) : null), [f, settings.standard]);
  if (!b || !f) return (<><PageHeader title="تعديل الكتلة" back="/history" />{ready ? <Empty title="لم نجد هذه الكتلة" /> : <p className="note">جارٍ التحميل…</p>}</>);
  const set = (p: Partial<typeof f>) => setF({ ...f, ...p });
  const save = async () => {
    if (busy) return;
    setBusy(true);
    try { await saveBlock({ id: b.id, ...f }); toast('تم حفظ التعديل وأُعيد الحساب'); navigate('/block/' + b.id); }
    catch (e) { toast(e instanceof Error ? e.message : 'تعذر الحفظ', 'err'); }
    finally { setBusy(false); }
  };
  return (
    <>
      <PageHeader title="تعديل الكتلة" back={'/block/' + b.id} />
      <Card>
        <label className="field"><span>العنوان</span><input value={f.title} onChange={(e) => set({ title: e.target.value })} /></label>
        <div className="grid2">
          <label className="field"><span>التصنيف</span><select value={f.category} onChange={(e) => set({ category: e.target.value })}><option value="">بدون تصنيف</option>{CATEGORIES.map((c) => <option key={c}>{c}</option>)}</select></label>
          <label className="field"><span>تاريخ الحفظ</span><input type="date" max={today()} value={f.date} onChange={(e) => set({ date: e.target.value || b.date })} /></label>
        </div>
        <label className="field"><span>النص</span><textarea rows={10} dir="auto" value={f.text} onChange={(e) => set({ text: e.target.value })} /></label>
        <label className="field"><span>ملاحظات</span><input value={f.notes} onChange={(e) => set({ notes: e.target.value })} /></label>
      </Card>
      {result && <ResultCards a={result} std={settings.standard} />}
      <div className="row">
        <button className="btn primary grow" disabled={busy || !result || result.words === 0} onClick={save}>{busy ? 'جارٍ الحفظ…' : 'احفظ التعديل'}</button>
        <button className="btn" onClick={() => navigate('/block/' + b.id)}>إلغاء</button>
      </div>
    </>
  );
}
