import { useState } from 'react';
import { useStore } from '../store';
import { today } from '../lib/dates';
import { quranPageCount, validateQuranRange } from '../lib/stats';
import { Card, Empty, PageHeader, confirmAction, fmt, toast } from '../components/ui';

export function Quran() {
  const { quran, settings, saveQuran, deleteQuran } = useStore();
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [date, setDate] = useState(today());
  const [notes, setNotes] = useState('');
  const [busy, setBusy] = useState(false);
  const f = from === '' ? NaN : Number(from), tt = to === '' ? NaN : Number(to);
  const err = from === '' && to === '' ? null : validateQuranRange(f, tt, settings.quranPages);
  const pages = !err && from !== '' && to !== '' ? quranPageCount(f, tt) : null;

  const save = async () => {
    if (busy) return;
    const e = validateQuranRange(f, tt, settings.quranPages);
    if (e) { toast(e, 'err'); return; }
    setBusy(true);
    try {
      await saveQuran({ fromPage: f, toPage: tt, date, notes });
      toast(`تم تسجيل ${quranPageCount(f, tt)} صفحة`);
      setFrom(''); setTo(''); setNotes('');
    } catch (x) { toast(x instanceof Error ? x.message : 'تعذر الحفظ', 'err'); }
    finally { setBusy(false); }
  };
  const sorted = [...quran].sort((a, b) => b.date.localeCompare(a.date) || b.createdAt - a.createdAt);

  return (
    <>
      <PageHeader title="الحفظ القرآني بالصفحات" />
      <Card>
        <p className="note">سجّل ما حفظته من المصحف مباشرة بأرقام الصفحات (مصحف من {fmt(settings.quranPages)} صفحة). لا حاجة للصق النص.</p>
        <div className="grid2">
          <label className="field"><span>من الصفحة</span><input type="number" inputMode="numeric" min={1} max={settings.quranPages} value={from} onChange={(e) => setFrom(e.target.value)} /></label>
          <label className="field"><span>إلى الصفحة</span><input type="number" inputMode="numeric" min={1} max={settings.quranPages} value={to} onChange={(e) => setTo(e.target.value)} /></label>
        </div>
        <div className="field"><span>عدد الصفحات</span><div className="readout">{pages !== null ? fmt(pages) : '—'}</div></div>
        {err && <p className="banner err">{err}</p>}
        <label className="field"><span>تاريخ الحفظ</span><input type="date" max={today()} value={date} onChange={(e) => setDate(e.target.value || today())} /></label>
        <label className="field"><span>ملاحظات (اختياري)</span><input value={notes} onChange={(e) => setNotes(e.target.value)} /></label>
        <button className="btn primary block" disabled={busy || !!err || pages === null} onClick={save}>{busy ? 'جارٍ الحفظ…' : 'سجّل الحفظ القرآني'}</button>
        <p className="note">عدد الصفحات = الصفحة الأخيرة − الصفحة الأولى + 1. ويُعدّ كل صفحة وجهًا واحدًا.</p>
      </Card>
      <h2 className="section-title">سجلات القرآن</h2>
      {sorted.length === 0 ? <Empty title="لا توجد سجلات قرآنية بعد" /> : (
        <div className="stack">
          {sorted.map((e) => (
            <article key={e.id} className="block-card">
              <div className="block-top"><b>من صفحة {e.fromPage} إلى {e.toPage}</b><span className="chip">{e.pages} صفحة</span></div>
              <div className="block-meta"><span>{e.date}</span>{e.notes && <span>{e.notes}</span>}</div>
              <div className="block-actions"><button className="btn sm danger-outline" onClick={async () => { if (await confirmAction('حذف هذا السجل؟', 'حذف', true)) { try { await deleteQuran(e.id); toast('تم الحذف'); } catch { toast('تعذر الحذف', 'err'); } } }}>حذف</button></div>
            </article>
          ))}
        </div>
      )}
    </>
  );
}
