import { PageHeader } from '../components/ui';
import { AddBlockForm } from '../components/AddBlockForm';

export function AddPage() {
  return (
    <>
      <PageHeader title="إضافة كتلة حفظ" />
      <AddBlockForm />
    </>
  );
}
