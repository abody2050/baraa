import { useStore } from '../store';
import { formatLong, today, weekRange } from '../lib/dates';
import { inRange, sumBlocks } from '../lib/stats';
import { backupIsStale } from '../lib/backup';
import { Empty, Icon, Stat, fmt } from '../components/ui';
import { AddBlockForm } from '../components/AddBlockForm';
import { BlockCard } from '../components/BlockCard';

export function Home() {
  const { blocks, quran, settings, ready, updateSettings } = useStore();
  const t = today();
  const std = settings.standard;
  const todayBlocks = blocks.filter((b) => b.date === t).sort((a, b) => a.createdAt - b.createdAt);
  const sum = sumBlocks(todayBlocks, std);
  const wk = weekRange(t, settings.weekStart);
  const week = sumBlocks(inRange(blocks, wk.from, wk.to), std);
  const stale = backupIsStale(settings.lastBackup, settings.backupReminderDays, blocks.length + quran.length > 0);

  return (
    <>
      <header className="hero">
        <div className="hero-top">
          <span className="brand">رفيق الحفظ</span>
          <div className="spacer" />
          <button className="icon-btn light" aria-label="تبديل الوضع الليلي" onClick={() => updateSettings({ theme: settings.theme === 'dark' ? 'light' : 'dark' })}>
            <Icon name={settings.theme === 'dark' ? 'sun' : 'moon'} />
          </button>
          <a className="icon-btn light" href="#/history" aria-label="سجل الحفظ"><Icon name="book" /></a>
          <a className="icon-btn light" href="#/settings" aria-label="الإعدادات"><Icon name="gear" /></a>
        </div>
        <h1 className="greet">{settings.showName ? `أهلًا بك يا ${settings.userName}، واصل رحلتك في الحفظ` : 'أهلًا بك، واصل رحلتك في الحفظ'}</h1>
        <div className="date">{formatLong(t)}</div>
      </header>

      <section className="card summary" aria-label="ملخص اليوم">
        {!ready ? <p className="note">جارٍ التحميل…</p> : (
          <div className="stats">
            <Stat label="كلمة محفوظة اليوم" value={fmt(sum.words)} accent />
            <Stat label="وجه تقريبًا" value={fmt(sum.faces)} accent />
            <Stat label="سطر تقديري" value={fmt(sum.lines)} />
            <Stat label="كتل اليوم" value={fmt(sum.count)} />
            <Stat label="كلمة هذا الأسبوع" value={fmt(week.words)} hint={`≈ ${fmt(week.faces)} وجه`} />
          </div>
        )}
        <p className="note">الأوجه تقديرية: كل وجه = {std.wordsPerFace} كلمة وفق المعيار الحالي، وتستطيع تعديله من الإعدادات.</p>
      </section>

      {stale && (
        <div className="banner warn">
          مضى وقت دون نسخة احتياطية. <a href="#/data">نزّل نسخة احتياطية الآن</a> حتى لا تفقد سجلك إن مُسحت بيانات المتصفح.
        </div>
      )}

      {ready && blocks.length === 0 && quran.length === 0 && (
        <Empty title="ابدأ أول حفظ لك">
          الصق نص موعظة أو محاضرة في المربع أدناه، واضغط «احسب مقدار الحفظ»، ثم سجّلها. يمكنك تسجيل أكثر من كتلة في اليوم.
        </Empty>
      )}

      <AddBlockForm />

      {todayBlocks.length > 0 && (
        <section className="stack" aria-label="كتل اليوم">
          <h2 className="section-title">كتل اليوم ({todayBlocks.length})</h2>
          {todayBlocks.map((b) => <BlockCard key={b.id} b={b} />)}
          <p className="note">الإجمالي: {fmt(sum.words)} كلمة ≈ {fmt(sum.lines)} سطرًا ≈ {fmt(sum.faces)} وجهًا.</p>
        </section>
      )}
      <p className="center"><a href="#/quran" className="link-btn">سجّل حفظًا قرآنيًا بالصفحات</a> · <a href="#/help" className="link-btn">كيف أستخدم الموقع؟</a></p>
    </>
  );
}
