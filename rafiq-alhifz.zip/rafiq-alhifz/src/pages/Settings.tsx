import { useState } from 'react';
import { useStore } from '../store';
import { validateStandard } from '../lib/text';
import { DEFAULT_STANDARD } from '../lib/defaults';
import type { Standard } from '../lib/types';
import { Card, PageHeader, confirmAction, toast } from '../components/ui';
import { FONT_OPTIONS } from '../lib/defaults';

const DAYS = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];

export function Settings() {
  const { settings, updateSettings, resetSettings } = useStore();
  const [name, setName] = useState(settings.userName);
  const [std, setStd] = useState<Record<keyof Standard, string>>(() => toStr(settings.standard));
  const [quranPages, setQuranPages] = useState(String(settings.quranPages));
  const [errors, setErrors] = useState<string[]>([]);

  const saveStd = () => {
    const next = Object.fromEntries(Object.entries(std).map(([k, v]) => [k, v.trim() === '' ? NaN : Number(v)])) as unknown as Standard;
    const errs = validateStandard(next);
    const qp = Number(quranPages);
    if (!Number.isInteger(qp) || qp < 1 || qp > 2000) errs.push('عدد صفحات المصحف يجب أن يكون عددًا صحيحًا بين 1 و2000.');
    setErrors(errs);
    if (errs.length) { toast('صحّح القيم المشار إليها', 'err'); return; }
    updateSettings({ standard: next, quranPages: qp });
    toast('تم حفظ المعيار وأُعيد حساب النتائج المعروضة');
  };
  const f = (k: keyof Standard, label: string) => (
    <label className="field"><span>{label}</span><input type="number" inputMode="numeric" value={std[k]} onChange={(e) => setStd({ ...std, [k]: e.target.value })} /></label>
  );

  return (
    <>
      <PageHeader title="الإعدادات" back={null} />
      <Card title="الحساب الشخصي (محلي فقط)">
        <label className="field"><span>الاسم المعروض</span><input value={name} maxLength={40} onChange={(e) => setName(e.target.value)} /></label>
        <button className="btn" onClick={() => { if (!name.trim()) { toast('اكتب اسمًا', 'err'); return; } updateSettings({ userName: name.trim() }); toast('تم تغيير الاسم'); }}>حفظ الاسم</button>
        <label className="check"><input type="checkbox" checked={settings.showName} onChange={(e) => updateSettings({ showName: e.target.checked })} /> إظهار الاسم في الصفحة الرئيسية</label>
        <p className="note">لا يوجد تسجيل دخول ولا كلمة مرور؛ كل شيء محفوظ على جهازك.</p>
      </Card>

      <Card title="المظهر">
        <div className="seg">
          <button className={'btn' + (settings.theme === 'light' ? ' primary' : '')} onClick={() => updateSettings({ theme: 'light' })}>فاتح</button>
          <button className={'btn' + (settings.theme === 'dark' ? ' primary' : '')} onClick={() => updateSettings({ theme: 'dark' })}>ليلي</button>
        </div>
        <label className="field"><span>حجم خط الواجهة ({Math.round(settings.uiScale * 100)}%)</span><input type="range" min={0.9} max={1.3} step={0.05} value={settings.uiScale} onChange={(e) => updateSettings({ uiScale: +e.target.value })} /></label>
        <label className="field"><span>نوع خط المعاينة</span><select value={settings.previewFont} onChange={(e) => updateSettings({ previewFont: e.target.value })}>{FONT_OPTIONS.map((x) => <option key={x.label} value={x.value}>{x.label}</option>)}</select></label>
        <div className="grid2">
          <label className="field"><span>حجم نص المعاينة ({settings.previewFontSize})</span><input type="range" min={12} max={40} value={settings.previewFontSize} onChange={(e) => updateSettings({ previewFontSize: +e.target.value })} /></label>
          <label className="field"><span>ارتفاع الأسطر ({settings.previewLineHeight})</span><input type="range" min={1.3} max={2.8} step={0.1} value={settings.previewLineHeight} onChange={(e) => updateSettings({ previewLineHeight: +e.target.value })} /></label>
          <label className="field"><span>عرض الصفحة ({settings.previewPageWidth})</span><input type="range" min={280} max={800} step={10} value={settings.previewPageWidth} onChange={(e) => updateSettings({ previewPageWidth: +e.target.value })} /></label>
          <label className="field"><span>الهوامش ({settings.previewMargin})</span><input type="range" min={8} max={80} value={settings.previewMargin} onChange={(e) => updateSettings({ previewMargin: +e.target.value })} /></label>
          <label className="field"><span>لون خلفية المعاينة</span><input type="color" value={settings.previewBg} onChange={(e) => updateSettings({ previewBg: e.target.value })} /></label>
          <label className="field"><span>لون النص</span><input type="color" value={settings.previewColor} onChange={(e) => updateSettings({ previewColor: e.target.value })} /></label>
        </div>
      </Card>

      <Card title="معيار الحفظ">
        <p className="note">هذه القيم معيار حسابي <b>تقريبي</b> للمقارنة، وليست عدد الكلمات الحقيقي الثابت في كل وجه من المصحف. تعديلها يعيد حساب النتائج المعروضة دون المساس بنصوصك أو سجلك.</p>
        <div className="grid2">
          {f('wordsPerFace', 'عدد الكلمات المرجعي للوجه')}
          {f('linesPerFace', 'عدد الأسطر في الوجه')}
          {f('minWordsPerLine', 'الحد الأدنى للكلمات في السطر')}
          {f('targetWordsPerLine', 'العدد المستهدف للكلمات في السطر')}
          {f('maxWordsPerLine', 'الحد الأعلى للكلمات في السطر')}
          {f('facesPerJuz', 'عدد الأوجه المرجعي للجزء')}
        </div>
        <label className="field"><span>عدد صفحات المصحف</span><input type="number" inputMode="numeric" value={quranPages} onChange={(e) => setQuranPages(e.target.value)} /></label>
        <label className="field"><span>يوم بداية الأسبوع</span><select value={settings.weekStart} onChange={(e) => updateSettings({ weekStart: +e.target.value })}>{DAYS.map((d, i) => <option key={d} value={i}>{d}</option>)}</select></label>
        {errors.map((e) => <p key={e} className="banner err">{e}</p>)}
        <div className="row wrap">
          <button className="btn primary" onClick={saveStd}>حفظ المعيار</button>
          <button className="btn" onClick={() => { setStd(toStr(DEFAULT_STANDARD)); setQuranPages('604'); setErrors([]); }}>القيم الافتراضية</button>
        </div>
      </Card>

      <Card title="النسخ الاحتياطي">
        <label className="field"><span>تذكير بالنسخ الاحتياطي كل (يوم) — 0 لإيقافه</span><input type="number" min={0} max={365} value={settings.backupReminderDays} onChange={(e) => updateSettings({ backupReminderDays: Math.max(0, Math.round(+e.target.value || 0)) })} /></label>
        <a className="btn block" href="#/data">إدارة البيانات والنسخ الاحتياطي</a>
      </Card>

      <Card title="إعادة الضبط">
        <p className="note">يعيد الإعدادات إلى الوضع الافتراضي <b>دون حذف سجل الحفظ</b>. لحذف السجل استخدم صفحة إدارة البيانات.</p>
        <button className="btn danger-outline" onClick={async () => { if (await confirmAction('إعادة كل الإعدادات إلى الافتراضي؟ (سجل الحفظ لن يُحذف)', 'إعادة الضبط', true)) { resetSettings(); setStd(toStr(DEFAULT_STANDARD)); setQuranPages('604'); setName('براء'); toast('أُعيدت الإعدادات'); } }}>إعادة الإعدادات</button>
      </Card>
      <p className="center"><a className="link-btn" href="#/help">المساعدة</a> · <a className="link-btn" href="#/quran">الحفظ القرآني</a></p>
    </>
  );
}

function toStr(s: Standard): Record<keyof Standard, string> {
  return Object.fromEntries(Object.entries(s).map(([k, v]) => [k, String(v)])) as Record<keyof Standard, string>;
}
