import { useEffect, useState, type ReactNode } from 'react';
import { useStore } from '../store';

const ICONS: Record<string, string> = {
  home: 'M3 11.5 12 4l9 7.5M5.5 10v9.5h4.5v-5.5h4v5.5h4.5V10',
  book: 'M5 4.5h10a3 3 0 0 1 3 3V20H8a3 3 0 0 1-3-3V4.5ZM5 17a3 3 0 0 1 3-3h10',
  chart: 'M4 20V10M10 20V4M16 20v-7M22 20H2',
  gear: 'M4 7h9M17 7h3M4 17h3M11 17h9M15 4v6M9 14v6',
  plus: 'M12 5v14M5 12h14',
  moon: 'M20 14.5A8 8 0 0 1 9.500 4 8.500 8.500 0 1 0 20 14.500Z',
  sun: 'M12 16a4 4 0 1 0 0-8 4 4 0 0 0 0 8ZM12 2.500v2M12 19.500v2M4.500 12h-2M21.500 12h-2M5.200 5.200l1.400 1.400M17.400 17.400l1.400 1.400M5.200 18.800l1.400-1.400M17.400 6.600l1.400-1.400',
  back: 'M9 5l7 7-7 7',
  help: 'M9.500 9a2.500 2.500 0 1 1 3.500 2.300c-.7.400-1 .9-1 1.700M12 17v.5M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18Z',
};

export function Icon({ name, size = 22 }: { name: keyof typeof ICONS | string; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={ICONS[name] ?? ''} />
    </svg>
  );
}

export const fmt = (n: number): string => new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 }).format(n);

/* ---------- نافذة التأكيد ---------- */
type Pending = { message: string; ok: string; danger: boolean; res: (v: boolean) => void };
let openConfirm: ((m: string, ok?: string, danger?: boolean) => Promise<boolean>) | null = null;
export const confirmAction = (message: string, ok = 'تأكيد', danger = false): Promise<boolean> =>
  openConfirm ? openConfirm(message, ok, danger) : Promise.resolve(window.confirm(message));

type ToastItem = { id: number; text: string; kind: 'ok' | 'err' };
let pushToast: ((t: string, k: 'ok' | 'err') => void) | null = null;
export const toast = (text: string, kind: 'ok' | 'err' = 'ok') => pushToast?.(text, kind);

export function Overlays() {
  const [pending, setPending] = useState<Pending | null>(null);
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  useEffect(() => {
    openConfirm = (message, ok = 'تأكيد', danger = false) => new Promise((res) => setPending({ message, ok, danger, res }));
    pushToast = (text, kind) => {
      const id = Date.now() + Math.random();
      setToasts((t) => [...t, { id, text, kind }]);
      setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3500);
    };
    return () => { openConfirm = null; pushToast = null; };
  }, []);
  const close = (v: boolean) => { pending?.res(v); setPending(null); };
  return (
    <>
      {pending && (
        <div className="modal-back no-print" role="dialog" aria-modal="true" onClick={() => close(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <p>{pending.message}</p>
            <div className="row end">
              <button className="btn" onClick={() => close(false)}>إلغاء</button>
              <button className={'btn ' + (pending.danger ? 'danger' : 'primary')} onClick={() => close(true)} autoFocus>{pending.ok}</button>
            </div>
          </div>
        </div>
      )}
      <div className="toasts no-print" aria-live="polite">
        {toasts.map((t) => <div key={t.id} className={'toast ' + t.kind}>{t.text}</div>)}
      </div>
    </>
  );
}

/* ---------- مؤشر حالة التخزين ---------- */
export function StorageBadge() {
  const { status, statusMessage } = useStore();
  if (status === 'idle') return null;
  const map = {
    saving: ['جارٍ الحفظ…', 'info'],
    saved: ['تم الحفظ', 'ok'],
    error: ['تعذر الحفظ', 'err'],
    unavailable: ['تعذر الوصول إلى التخزين المحلي', 'err'],
  } as const;
  const [label, cls] = map[status as keyof typeof map];
  return (
    <div className={'storage-badge no-print ' + cls} role="status">
      {label}{statusMessage && status !== 'saved' ? ` — ${statusMessage}` : ''}
    </div>
  );
}

export function Card({ title, children, className = '', right }: { title?: string; children: ReactNode; className?: string; right?: ReactNode }) {
  return (
    <section className={'card ' + className}>
      {(title || right) && (
        <div className="card-head">
          {title && <h2>{title}</h2>}
          {right}
        </div>
      )}
      {children}
    </section>
  );
}

export function Stat({ label, value, hint, accent }: { label: string; value: ReactNode; hint?: string; accent?: boolean }) {
  return (
    <div className={'stat' + (accent ? ' accent' : '')}>
      <div className="stat-value">{value}</div>
      <div className="stat-label">{label}</div>
      {hint && <div className="stat-hint">{hint}</div>}
    </div>
  );
}

export function Empty({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="empty">
      <strong>{title}</strong>
      {children && <p>{children}</p>}
    </div>
  );
}

export const EstimateNote = () => (
  <p className="note">
    الأوجه والأسطر والأجزاء قيم <b>تقديرية</b> ناتجة عن معيار حسابي قابل للتعديل (الوجه = عدد كلمات مرجعي)، وليست مطابقة دقيقة لعدد الكلمات في صفحات المصحف.
  </p>
);

export function PageHeader({ title, back = '/', actions }: { title: string; back?: string | null; actions?: ReactNode }) {
  return (
    <header className="page-head no-print">
      {back && (
        <a className="icon-btn" href={'#' + back} aria-label="رجوع"><Icon name="back" /></a>
      )}
      <h1>{title}</h1>
      <div className="spacer" />
      {actions}
    </header>
  );
}

export function Bars({ data, unit }: { data: { label: string; value: number }[]; unit: string }) {
  const max = Math.max(1, ...data.map((d) => d.value));
  const w = Math.max(280, data.length * 22);
  const h = 140;
  const bw = w / data.length;
  return (
    <div className="chart" role="img" aria-label={`رسم بياني للحفظ (${unit})`}>
      <svg viewBox={`0 0 ${w} ${h + 26}`} preserveAspectRatio="none" width="100%" height="170">
        <line x1="0" y1={h} x2={w} y2={h} className="axis" />
        {data.map((d, i) => {
          const bh = (d.value / max) * (h - 18);
          const x = w - (i + 1) * bw + bw * 0.15;
          return (
            <g key={i}>
              <title>{`${d.label}: ${fmt(d.value)} ${unit}`}</title>
              <rect x={x} y={h - bh} width={bw * 0.7} height={Math.max(bh, d.value > 0 ? 2 : 0)} rx="3" className="bar" />
              {(data.length <= 10 || i % 5 === 0 || i === data.length - 1) && (
                <text x={x + bw * 0.35} y={h + 16} textAnchor="middle" className="axis-label">{d.label}</text>
              )}
            </g>
          );
        })}
      </svg>
    </div>
  );
}
