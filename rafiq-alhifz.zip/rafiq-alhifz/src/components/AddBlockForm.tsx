import { useEffect, useMemo, useRef, useState } from 'react';
import { useStore } from '../store';
import { analyze } from '../lib/text';
import { CATEGORIES } from '../lib/defaults';
import { newId } from '../lib/db';
import { today } from '../lib/dates';
import { navigate } from '../router';
import { Card, confirmAction, toast } from './ui';
import { ResultCards } from './ResultCards';

const DRAFT_KEY = 'rafiq.draft';
export interface Draft { id: string; title: string; category: string; text: string; date: string; notes: string }

export const emptyDraft = (): Draft => ({ id: newId(), title: '', category: '', text: '', date: today(), notes: '' });

export function readDraft(): Draft {
  try {
    const raw = sessionStorage.getItem(DRAFT_KEY);
    if (raw) {
      const d = JSON.parse(raw) as Draft;
      if (d && typeof d.text === 'string' && d.id) return { ...emptyDraft(), ...d };
    }
  } catch { /* ignore */ }
  return emptyDraft();
}
function writeDraft(d: Draft) {
  try { sessionStorage.setItem(DRAFT_KEY, JSON.stringify(d)); } catch { /* ignore */ }
}

export function AddBlockForm() {
  const { settings, saveBlock, status } = useStore();
  const [draft, setDraft] = useState<Draft>(readDraft);
  const [calcText, setCalcText] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [savedMsg, setSavedMsg] = useState('');
  const [showNotes, setShowNotes] = useState(false);
  const resultRef = useRef<HTMLDivElement>(null);

  useEffect(() => writeDraft(draft), [draft]);
  const set = (patch: Partial<Draft>) => { setDraft((d) => ({ ...d, ...patch })); setSavedMsg(''); };

  const result = useMemo(() => (calcText === null ? null : analyze(calcText, settings.standard)), [calcText, settings.standard]);
  const stale = calcText !== null && calcText !== draft.text;
  const hasText = draft.text.trim().length > 0;

  const calc = () => {
    if (!hasText) { toast('الصق نصًا أولًا ثم اضغط «احسب مقدار الحفظ».', 'err'); return; }
    setCalcText(draft.text);
    setTimeout(() => resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 50);
  };

  const clear = async () => {
    if (draft.text.trim() && !(await confirmAction('النص لم يُسجَّل بعد. هل تريد مسحه؟', 'مسح', true))) return;
    setDraft((d) => ({ ...d, text: '' }));
    setCalcText(null);
  };

  const save = async () => {
    if (busy) return;
    if (!result || result.words === 0) { toast('احسب مقدار الحفظ أولًا.', 'err'); return; }
    if (stale) { toast('تغيّر النص بعد الحساب؛ اضغط «احسب» مرة أخرى قبل التسجيل.', 'err'); return; }
    setBusy(true);
    try {
      const b = await saveBlock({ id: draft.id, title: draft.title, category: draft.category, text: draft.text, date: draft.date, notes: draft.notes });
      setSavedMsg(`تم تسجيل «${b.title}» (${result.words} كلمة) في حفظ ${draft.date === today() ? 'اليوم' : draft.date}.`);
      setDraft(emptyDraft());
      setCalcText(null);
      toast('تم الحفظ');
    } catch (e) {
      toast(e instanceof Error ? e.message : 'تعذر الحفظ', 'err');
    } finally { setBusy(false); }
  };

  const disabled = status === 'unavailable';

  return (
    <>
      <Card title="أضف حفظًا جديدًا">
        {disabled && <p className="banner err">التخزين المحلي غير متاح، لذلك لن يمكن تسجيل الحفظ. يمكنك مع ذلك حساب المقدار ومعاينته.</p>}
        {savedMsg && <p className="banner ok">{savedMsg}</p>}
        <label className="field">
          <span>عنوان الكتلة</span>
          <input value={draft.title} onChange={(e) => set({ title: e.target.value })} placeholder="مثال: موعظة الشمس والصلاة" maxLength={200} />
        </label>
        <div className="grid2">
          <label className="field">
            <span>التصنيف (اختياري)</span>
            <select value={draft.category} onChange={(e) => set({ category: e.target.value })}>
              <option value="">بدون تصنيف</option>
              {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
            </select>
          </label>
          <label className="field">
            <span>تاريخ الحفظ</span>
            <input type="date" value={draft.date} max={today()} onChange={(e) => set({ date: e.target.value || today() })} />
          </label>
        </div>
        <label className="field">
          <span>النص المحفوظ</span>
          <textarea value={draft.text} onChange={(e) => set({ text: e.target.value })} rows={9} placeholder="الصق المحاضرة أو الموعظة هنا…" dir="auto" />
        </label>
        {showNotes ? (
          <label className="field">
            <span>ملاحظات (اختياري)</span>
            <input value={draft.notes} onChange={(e) => set({ notes: e.target.value })} />
          </label>
        ) : (
          <button className="link-btn" onClick={() => setShowNotes(true)}>+ إضافة ملاحظة</button>
        )}
        <div className="row wrap">
          <button className="btn primary grow" onClick={calc}>احسب مقدار الحفظ</button>
          <button className="btn" onClick={() => { writeDraft(draft); navigate('/preview'); }} disabled={!hasText}>معاينة الصفحات</button>
          <button className="btn" onClick={clear} disabled={!hasText}>مسح النص</button>
        </div>
      </Card>

      <div ref={resultRef}>
        {result && (
          <>
            {stale && <p className="banner warn">تغيّر النص بعد الحساب، فالنتيجة أدناه للنص السابق. اضغط «احسب» لتحديثها.</p>}
            <ResultCards a={result} std={settings.standard} />
            <button className="btn primary block" onClick={save} disabled={busy || disabled || stale || result.words === 0}>
              {busy ? 'جارٍ الحفظ…' : 'سجّل كتلة الحفظ'}
            </button>
            <p className="note">لا يُسجَّل النص قبل أن تراجع النتيجة وتضغط هذا الزر.</p>
          </>
        )}
      </div>
    </>
  );
}
