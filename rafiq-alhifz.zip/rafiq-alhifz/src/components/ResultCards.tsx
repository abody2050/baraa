import type { Analysis } from '../lib/text';
import type { Standard } from '../lib/types';
import { Card, EstimateNote, Stat, fmt } from './ui';

export function ResultCards({ a, std }: { a: Analysis; std: Standard }) {
  return (
    <Card title="نتيجة الحساب">
      <div className="stats">
        <Stat label="كلمة (العدد الحقيقي)" value={fmt(a.words)} accent />
        <Stat label="وجه تقريبًا" value={fmt(a.faces)} hint={`كل وجه = ${std.wordsPerFace} كلمة`} accent />
        <Stat label="سطر حسابي" value={fmt(a.estLines)} hint={`${std.targetWordsPerLine} كلمات في السطر`} />
        <Stat label="جزء تقريبًا" value={fmt(a.juz)} hint={`${std.facesPerJuz} وجهًا للجزء`} />
        <Stat label="سطر أصلي في النص" value={fmt(a.textLines)} hint="بعد حذف الأسطر الفارغة" />
        <Stat label="حرف" value={fmt(a.chars)} hint="حروف الكلمات فقط، دون تشكيل أو ترقيم أو مسافات" />
      </div>
      <p className="note">
        يعادل نحو <b>{fmt(a.fullFaces)}</b> وجهًا كاملًا
        {a.remainderWords > 0 ? <> وبقية <b>{fmt(a.remainderWords)}</b> كلمة (≈ {fmt(a.remainderFraction)} من وجه)</> : null}.
      </p>
      <EstimateNote />
    </Card>
  );
}
