import { useLayoutEffect, useRef, useState } from 'react';
import type { Face } from '../lib/layout';
import type { Settings } from '../lib/types';

interface Props {
  face: Face;
  total: number;
  settings: Settings;
  zoom: number;
  hiddenOnScreen?: boolean;
}

/**
 * وجه واحد: كل سطر حاوية مستقلة (white-space: nowrap) وكلماتها موزعة مسبقًا.
 * لا يلتف النص أبدًا؛ إذا ضاق العرض يُصغَّر الخط تلقائيًا حتى حدٍّ أدنى ثم يظهر تنبيه.
 */
export function FacePage({ face, total, settings, zoom, hiddenOnScreen }: Props) {
  const bodyRef = useRef<HTMLDivElement>(null);
  const [fit, setFit] = useState<'ok' | 'shrunk' | 'cannot'>('ok');
  const lines = settings.standard.linesPerFace;
  const fontPx = settings.previewFontSize * zoom;
  const lineH = fontPx * settings.previewLineHeight;
  const margin = settings.previewMargin * zoom;
  const width = settings.previewPageWidth * zoom;

  useLayoutEffect(() => {
    const body = bodyRef.current;
    if (!body) return;
    const measure = () => {
      body.style.fontSize = fontPx + 'px';
      let ratio = 1;
      body.querySelectorAll<HTMLElement>('.fline').forEach((el) => {
        if (el.scrollWidth > el.clientWidth + 0.5) ratio = Math.min(ratio, el.clientWidth / el.scrollWidth);
      });
      const final = Math.max(ratio * 0.98, 0.55);
      if (ratio < 1) body.style.fontSize = fontPx * final + 'px';
      setFit(ratio >= 1 ? 'ok' : ratio * 0.98 >= 0.55 ? 'shrunk' : 'cannot');
    };
    measure();
    const ro = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(measure) : null;
    ro?.observe(body);
    return () => ro?.disconnect();
  }, [face, fontPx, width, margin, settings.previewFont, settings.previewAlign, settings.previewMargin]);

  const justify = settings.previewAlign === 'justify';
  const jc = settings.previewAlign === 'center' ? 'center' : justify ? 'space-between' : 'flex-start';

  return (
    <article
      className={'face-page' + (hiddenOnScreen ? ' screen-hidden' : '')}
      style={{ width, maxWidth: '100%', background: settings.previewBg, color: settings.previewColor, padding: `${margin * 0.8}px ${margin}px` }}
      aria-label={`الوجه ${face.number}`}
    >
      <div className="face-title">
        الوجه {face.number}
        {face.partial && <span className="partial"> — وجه جزئي ({face.lines.length} من {lines} أسطر)</span>}
      </div>
      <div ref={bodyRef} className="face-body" style={{ fontFamily: settings.previewFont, fontSize: fontPx }}>
        {face.lineWords.map((ws, i) => (
          <div
            key={i}
            className="fline"
            style={{ height: lineH, lineHeight: lineH + 'px', justifyContent: justify && ws.length < settings.standard.minWordsPerLine ? 'flex-start' : jc }}
          >
            {ws.map((w, k) => <span key={k}>{w}</span>)}
          </div>
        ))}
      </div>
      <div className="face-foot">{face.number} / {total}</div>
      {fit !== 'ok' && (
        <div className="fit-warn no-print">
          {fit === 'shrunk' ? 'صُغِّر الخط تلقائيًا ليتسع السطر دون التفاف.' : 'تعذر إظهار الأسطر كاملة بهذا العرض؛ زد عرض الصفحة أو قلّل حجم الخط أو الهوامش.'}
        </div>
      )}
    </article>
  );
}
