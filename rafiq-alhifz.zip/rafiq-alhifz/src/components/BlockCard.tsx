import type { Block } from '../lib/types';
import { derive } from '../lib/text';
import { useStore } from '../store';
import { navigate } from '../router';
import { confirmAction, fmt, toast } from './ui';
import { formatShort } from '../lib/dates';

export async function copyText(text: string): Promise<void> {
  try {
    await navigator.clipboard.writeText(text);
    toast('تم نسخ النص');
  } catch {
    try {
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      ta.remove();
      toast('تم نسخ النص');
    } catch {
      toast('تعذر نسخ النص في هذا المتصفح', 'err');
    }
  }
}

export function BlockCard({ b, showDate = false }: { b: Block; showDate?: boolean }) {
  const { settings, deleteBlock, recalcBlock } = useStore();
  const d = derive(b.words, settings.standard);

  const del = async () => {
    if (!(await confirmAction(`حذف الكتلة «${b.title}» نهائيًا؟ لا يمكن التراجع.`, 'حذف', true))) return;
    try { await deleteBlock(b.id); toast('تم حذف الكتلة'); } catch { toast('تعذر الحذف', 'err'); }
  };
  const recalc = async () => {
    try { await recalcBlock(b.id); toast('أُعيد حساب الكتلة وفق المعيار الحالي'); } catch { toast('تعذرت إعادة الحساب', 'err'); }
  };

  return (
    <article className="block-card">
      <div className="block-top">
        <a className="block-title" href={'#/block/' + b.id}>{b.title}</a>
        {b.category && <span className="chip">{b.category}</span>}
      </div>
      <div className="block-meta">
        {showDate && <span>{formatShort(b.date)}</span>}
        <span>{fmt(b.words)} كلمة</span>
        <span>≈ {fmt(d.lines)} سطر</span>
        <span>≈ {fmt(d.faces)} وجه</span>
      </div>
      <div className="block-actions">
        <button className="btn sm" onClick={() => navigate('/preview/' + b.id)}>معاينة</button>
        <button className="btn sm" onClick={() => navigate('/block/' + b.id)}>التفاصيل</button>
        <button className="btn sm" onClick={() => navigate('/edit/' + b.id)}>تعديل</button>
        <button className="btn sm" onClick={recalc}>إعادة الحساب</button>
        <button className="btn sm" onClick={() => copyText(b.text)}>نسخ النص</button>
        <button className="btn sm danger-outline" onClick={del}>حذف</button>
      </div>
    </article>
  );
}
