import { useEffect, useState } from 'react';

export const getPath = (): string => {
  const h = window.location.hash.replace(/^#/, '');
  return h.startsWith('/') ? h : '/';
};

export function navigate(path: string): void {
  if (getPath() === path) window.dispatchEvent(new HashChangeEvent('hashchange'));
  else window.location.hash = path;
}

export function usePath(): string {
  const [p, setP] = useState(getPath);
  useEffect(() => {
    const on = () => setP(getPath());
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  return p;
}
