import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import { StoreProvider } from './store';
import './styles.css';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <StoreProvider>
      <App />
    </StoreProvider>
  </StrictMode>,
);

if ('serviceWorker' in navigator && import.meta.env.PROD) {
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('/sw.js')
      .then(() => navigator.serviceWorker.ready)
      .then((reg) => {
        // نخزّن موارد الصفحة الحالية (JS/CSS) ليعمل التطبيق دون اتصال بعد أول تحميل
        const urls = performance.getEntriesByType('resource').map((r) => r.name).filter((u) => u.startsWith(location.origin));
        reg.active?.postMessage({ type: 'CACHE_URLS', urls: [...urls, location.origin + '/'] });
      })
      .catch(() => { /* التسجيل اختياري */ });
  });
}
