import type { Block, QuranEntry, Standard } from './types';
import { derive, round2 } from './text';
import { addDays } from './dates';

export interface Totals {
  count: number;
  words: number;
  chars: number;
  lines: number;
  faces: number;
  juz: number;
}

/** كل القيم المشتقة تُحسب من عدد الكلمات المخزّن والمعيار الحالي (فلا تتكرر ولا تتأثر بتعديل النص دون تحديث). */
export function sumBlocks(blocks: Block[], std: Standard): Totals {
  const words = blocks.reduce((a, b) => a + b.words, 0);
  const chars = blocks.reduce((a, b) => a + b.chars, 0);
  const d = derive(words, std);
  return { count: blocks.length, words, chars, lines: d.lines, faces: d.faces, juz: d.juz };
}

export function inRange<T extends { date: string }>(items: T[], from: string, to: string): T[] {
  return items.filter((i) => i.date >= from && i.date <= to);
}

export function groupByDate<T extends { date: string }>(items: T[]): Map<string, T[]> {
  const m = new Map<string, T[]>();
  for (const it of items) {
    const arr = m.get(it.date);
    if (arr) arr.push(it);
    else m.set(it.date, [it]);
  }
  return m;
}

export function dailySeries(blocks: Block[], endDate: string, days: number): { date: string; words: number }[] {
  const g = groupByDate(blocks);
  const out: { date: string; words: number }[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const date = addDays(endDate, -i);
    out.push({ date, words: (g.get(date) ?? []).reduce((a, b) => a + b.words, 0) });
  }
  return out;
}

export interface Overview {
  totals: Totals;
  activeDays: number;
  avgWordsPerActiveDay: number;
  bestDay: { date: string; words: number } | null;
}

export function overview(blocks: Block[], std: Standard): Overview {
  const g = groupByDate(blocks);
  let best: { date: string; words: number } | null = null;
  for (const [date, arr] of g) {
    const w = arr.reduce((a, b) => a + b.words, 0);
    if (w > 0 && (!best || w > best.words)) best = { date, words: w };
  }
  const totals = sumBlocks(blocks, std);
  const activeDays = Array.from(g.values()).filter((arr) => arr.some((b) => b.words > 0)).length;
  return {
    totals,
    activeDays,
    avgWordsPerActiveDay: activeDays ? Math.round(totals.words / activeDays) : 0,
    bestDay: best,
  };
}

export function quranTotals(entries: QuranEntry[]) {
  const pages = entries.reduce((a, e) => a + e.pages, 0);
  return { count: entries.length, pages, faces: pages };
}

export function combined(blocks: Block[], quran: QuranEntry[], std: Standard) {
  const text = sumBlocks(blocks, std);
  const q = quranTotals(quran);
  return { quranFaces: q.faces, textFaces: text.faces, total: round2(q.faces + text.faces) };
}

/** عدد صفحات نطاق قرآني: الأخيرة − الأولى + 1 */
export function quranPageCount(from: number, to: number): number {
  return to - from + 1;
}

export function validateQuranRange(from: number, to: number, maxPages: number): string | null {
  if (!Number.isInteger(from) || !Number.isInteger(to)) return 'أدخل أرقام صفحات صحيحة.';
  if (from < 1 || to < 1) return 'رقم الصفحة يجب أن يكون 1 أو أكثر.';
  if (from > to) return 'الصفحة الأولى يجب ألا تتجاوز الصفحة الأخيرة.';
  if (to > maxPages) return `رقم الصفحة الأخيرة يتجاوز عدد صفحات المصحف (${maxPages}).`;
  return null;
}
