import type { Settings, Standard } from './types';

export const DEFAULT_STANDARD: Standard = {
  linesPerFace: 15,
  minWordsPerLine: 8,
  targetWordsPerLine: 10,
  maxWordsPerLine: 12,
  wordsPerFace: 150,
  facesPerJuz: 20,
};

export const CATEGORIES = ['موعظة', 'محاضرة', 'درس', 'كتاب', 'حديث', 'نص آخر'];

export const FONT_OPTIONS: { label: string; value: string }[] = [
  { label: 'نسخ (أميري / نوتو نسخ)', value: "'Amiri', 'Noto Naskh Arabic', 'Scheherazade New', 'Traditional Arabic', 'Geeza Pro', 'Segoe UI', Tahoma, serif" },
  { label: 'مصحف (القلم / شهرزاد)', value: "'KFGQPC Uthmanic Script HAFS', 'Scheherazade New', 'Amiri Quran', 'Amiri', 'Traditional Arabic', 'Geeza Pro', serif" },
  { label: 'نظام (بسيط)', value: "system-ui, 'Segoe UI', Tahoma, 'Geeza Pro', sans-serif" },
];

export const DEFAULT_SETTINGS: Settings = {
  userName: 'براء',
  showName: true,
  theme: 'light',
  uiScale: 1,
  previewFont: FONT_OPTIONS[0].value,
  previewFontSize: 22,
  previewLineHeight: 1.9,
  previewPageWidth: 440,
  previewMargin: 24,
  previewAlign: 'justify',
  previewBg: '#fffdf5',
  previewColor: '#1b1b1b',
  previewMode: 'single',
  quranPages: 604,
  weekStart: 6,
  standard: DEFAULT_STANDARD,
  lastBackup: null,
  backupReminderDays: 14,
};
