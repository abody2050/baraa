import type { Standard } from './types';

/**
 * معالجة النص العربي: التنظيف والتقسيم إلى كلمات وحساب التقديرات.
 * كل الدوال هنا "نقية" ولا تعدّل النص الأصلي أبدًا.
 */

// حروف خفية لا تظهر (علامات الاتجاه والتضمين وغيرها)
const INVISIBLE = /[\u200C-\u200F\u202A-\u202E\u2060-\u2069\uFEFF\u00AD]/g;
// كل أنواع المسافات (تشمل المسافة الصفرية العرض U+200B كفاصل)
const SPACES = /[\s\u00A0\u1680\u2000-\u200B\u2028\u2029\u202F\u205F\u3000]+/;
// التشكيل وعلامات الوقف القرآنية والتطويل
const TASHKEEL = /[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06DC\u06DF-\u06E8\u06EA-\u06ED\u08D3-\u08FF]/g;
const TATWEEL = /\u0640/g;
// كتلة الكلمة: حروف وأرقام وعلامات متصلة (مع أرقام عشرية)
const WORD_RUN = /[\p{L}\p{N}\p{M}\u0640\u06D6-\u06DC\u06DF-\u06E8\u06EA-\u06ED]+(?:[.,\u066B\u066C][\p{N}]+)*/gu;
const DIGITS_ONLY = /^[\p{N}]+$/u;
const AYAH_MARKS = /[\u06DD\uFD3E\uFD3F()\[\]]/;

export function stripInvisible(s: string): string {
  return s.replace(INVISIBLE, '');
}

/** نسخة الحساب: بلا تشكيل ولا تطويل ولا حروف خفية (لا تُخزَّن ولا تحل محل الأصل). */
export function cleanForCount(s: string): string {
  return stripInvisible(s).replace(TASHKEEL, '').replace(TATWEEL, '');
}

/**
 * يقسّم النص إلى "كلمات عرض": كل عنصر كلمة واحدة تحتفظ بعلامات ترقيمها وتشكيلها،
 * أما الرموز المنفصلة (۝ وأرقام الآيات والشرطات) فتُلحق بالكلمة السابقة ولا تُحتسب كلمات.
 */
export function tokenize(text: string): string[] {
  const raw = stripInvisible(text).split(SPACES).filter((t) => t.length > 0);
  const out: string[] = [];
  let leading = ''; // رموز سبقت أول كلمة
  let prevRaw = '';

  const attach = (piece: string) => {
    if (out.length > 0) out[out.length - 1] += ' ' + piece;
    else leading = leading ? leading + ' ' + piece : piece;
  };
  const pushWord = (piece: string) => {
    if (leading) {
      out.push(leading + ' ' + piece);
      leading = '';
    } else out.push(piece);
  };

  for (const tok of raw) {
    const plain = tok.replace(TASHKEEL, '').replace(TATWEEL, '');
    const runs = Array.from(plain.matchAll(WORD_RUN));
    if (runs.length === 0) {
      attach(tok);
      prevRaw = tok;
      continue;
    }
    // رقم آية منفصل؟ (رقم داخل أقواس أو بعد رمز ۝)
    if (runs.length === 1 && DIGITS_ONLY.test(runs[0][0]) && (AYAH_MARKS.test(tok) || prevRaw.endsWith('\u06DD'))) {
      attach(tok);
      prevRaw = tok;
      continue;
    }
    // نقسم الرمز الأصلي (بتشكيله) عند حدود الكلمات داخل plain، لذا نحتاج مواقع في tok.
    // نعيد المسح على tok نفسه لأن التشكيل جزء من كتلة الكلمة في WORD_RUN.
    const tokRuns = Array.from(tok.matchAll(WORD_RUN)).filter((m) => /[\p{L}\p{N}]/u.test(m[0].replace(TASHKEEL, '').replace(TATWEEL, '')));
    if (tokRuns.length === 0) {
      attach(tok);
      prevRaw = tok;
      continue;
    }
    for (let k = 0; k < tokRuns.length; k++) {
      const start = k === 0 ? 0 : (tokRuns[k].index as number);
      const end = k === tokRuns.length - 1 ? tok.length : (tokRuns[k + 1].index as number);
      pushWord(tok.slice(start, end));
    }
    prevRaw = tok;
  }
  if (leading && out.length === 0) return [];
  return out;
}

export function countWords(text: string): number {
  return tokenize(text).length;
}

/** عدد الحروف = حروف وأرقام الكلمات فقط، بعد إزالة التشكيل والتطويل والترقيم والمسافات. */
export function countChars(text: string): number {
  let n = 0;
  for (const w of tokenize(text)) {
    const core = cleanForCount(w);
    for (const ch of core) if (/[\p{L}\p{N}]/u.test(ch)) n++;
  }
  return n;
}

/** عدد الأسطر النصية الأصلية غير الفارغة. */
export function countTextLines(text: string): number {
  return stripInvisible(text)
    .split(/\r\n|\r|\n|\u2028|\u2029/)
    .filter((l) => l.replace(SPACES, '').length > 0).length;
}

export const round2 = (n: number): number => Math.round((n + Number.EPSILON) * 100) / 100;

export interface Analysis {
  words: number;
  chars: number;
  textLines: number;
  estLines: number;
  faces: number;
  juz: number;
  fullFaces: number;
  remainderWords: number;
  remainderFraction: number;
}

export function derive(words: number, std: Standard) {
  return {
    lines: round2(words / std.targetWordsPerLine),
    faces: round2(words / std.wordsPerFace),
    juz: round2(words / std.wordsPerFace / std.facesPerJuz),
  };
}

export function analyze(text: string, std: Standard): Analysis {
  const words = countWords(text);
  const d = derive(words, std);
  const fullFaces = Math.floor(words / std.wordsPerFace);
  const remainderWords = words - fullFaces * std.wordsPerFace;
  return {
    words,
    chars: countChars(text),
    textLines: countTextLines(text),
    estLines: d.lines,
    faces: d.faces,
    juz: d.juz,
    fullFaces,
    remainderWords,
    remainderFraction: round2(remainderWords / std.wordsPerFace),
  };
}

export function validateStandard(s: Standard): string[] {
  const errors: string[] = [];
  const isPosInt = (n: number) => Number.isInteger(n) && n > 0;
  if (!isPosInt(s.linesPerFace) || s.linesPerFace > 60) errors.push('عدد الأسطر في الوجه يجب أن يكون عددًا صحيحًا بين 1 و60.');
  if (!isPosInt(s.minWordsPerLine)) errors.push('الحد الأدنى للكلمات في السطر يجب أن يكون عددًا صحيحًا موجبًا.');
  if (!isPosInt(s.targetWordsPerLine)) errors.push('العدد المستهدف للكلمات في السطر يجب أن يكون عددًا صحيحًا موجبًا.');
  if (!isPosInt(s.maxWordsPerLine) || s.maxWordsPerLine > 60) errors.push('الحد الأعلى للكلمات في السطر يجب أن يكون عددًا صحيحًا بين 1 و60.');
  if (isPosInt(s.minWordsPerLine) && isPosInt(s.targetWordsPerLine) && isPosInt(s.maxWordsPerLine)) {
    if (!(s.minWordsPerLine <= s.targetWordsPerLine && s.targetWordsPerLine <= s.maxWordsPerLine))
      errors.push('يجب أن يكون: الحد الأدنى ≤ المستهدف ≤ الحد الأعلى.');
  }
  if (!isPosInt(s.wordsPerFace) || s.wordsPerFace > 2000) errors.push('عدد الكلمات المرجعي للوجه يجب أن يكون عددًا صحيحًا بين 1 و2000.');
  if (!isPosInt(s.facesPerJuz) || s.facesPerJuz > 100) errors.push('عدد الأوجه المرجعي للجزء يجب أن يكون عددًا صحيحًا بين 1 و100.');
  return errors;
}
