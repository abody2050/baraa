/** طبقة IndexedDB: المخزن الأساسي للسجلات. تُعتبر العملية ناجحة فقط بعد اكتمال المعاملة (oncomplete). */
export type StoreName = 'blocks' | 'quran';

const DB_NAME = 'rafiq-alhifz';
const DB_VERSION = 1;
let dbPromise: Promise<IDBDatabase> | null = null;

export function resetDbHandle(): void {
  dbPromise = null;
}

export function openDB(): Promise<IDBDatabase> {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise<IDBDatabase>((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('التخزين المحلي (IndexedDB) غير متاح في هذا المتصفح.'));
      return;
    }
    let req: IDBOpenDBRequest;
    try {
      req = indexedDB.open(DB_NAME, DB_VERSION);
    } catch (e) {
      reject(e instanceof Error ? e : new Error('تعذر فتح التخزين المحلي.'));
      return;
    }
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains('blocks')) db.createObjectStore('blocks', { keyPath: 'id' });
      if (!db.objectStoreNames.contains('quran')) db.createObjectStore('quran', { keyPath: 'id' });
    };
    req.onsuccess = () => {
      const db = req.result;
      db.onversionchange = () => {
        db.close();
        dbPromise = null;
      };
      resolve(db);
    };
    req.onerror = () => {
      dbPromise = null;
      reject(req.error ?? new Error('تعذر فتح التخزين المحلي.'));
    };
    req.onblocked = () => {
      dbPromise = null;
      reject(new Error('التخزين المحلي مشغول بنافذة أخرى. أغلق بقية نوافذ الموقع وأعد المحاولة.'));
    };
  });
  return dbPromise;
}

export async function getAll<T>(store: StoreName): Promise<T[]> {
  const db = await openDB();
  return new Promise<T[]>((resolve, reject) => {
    const t = db.transaction(store, 'readonly');
    const req = t.objectStore(store).getAll();
    req.onsuccess = () => resolve(req.result as T[]);
    req.onerror = () => reject(req.error ?? new Error('تعذرت قراءة السجلات.'));
  });
}

export async function putItems<T>(store: StoreName, items: T[]): Promise<void> {
  const db = await openDB();
  return new Promise<void>((resolve, reject) => {
    const t = db.transaction(store, 'readwrite');
    const os = t.objectStore(store);
    for (const it of items) os.put(it);
    t.oncomplete = () => resolve();
    t.onerror = () => reject(t.error ?? new Error('تعذرت الكتابة في التخزين المحلي.'));
    t.onabort = () => reject(t.error ?? new Error('أُلغيت عملية الكتابة (قد تكون مساحة التخزين ممتلئة).'));
  });
}

export async function removeItem(store: StoreName, id: string): Promise<void> {
  const db = await openDB();
  return new Promise<void>((resolve, reject) => {
    const t = db.transaction(store, 'readwrite');
    t.objectStore(store).delete(id);
    t.oncomplete = () => resolve();
    t.onerror = () => reject(t.error ?? new Error('تعذر الحذف.'));
    t.onabort = () => reject(t.error ?? new Error('أُلغيت عملية الحذف.'));
  });
}

export async function clearStores(): Promise<void> {
  const db = await openDB();
  return new Promise<void>((resolve, reject) => {
    const t = db.transaction(['blocks', 'quran'], 'readwrite');
    t.objectStore('blocks').clear();
    t.objectStore('quran').clear();
    t.oncomplete = () => resolve();
    t.onerror = () => reject(t.error ?? new Error('تعذر مسح البيانات.'));
    t.onabort = () => reject(t.error ?? new Error('أُلغيت عملية المسح.'));
  });
}

export async function requestPersistence(): Promise<boolean> {
  try {
    if (navigator.storage?.persisted && (await navigator.storage.persisted())) return true;
    if (navigator.storage?.persist) return await navigator.storage.persist();
  } catch {
    /* يتم تجاهل الرفض بهدوء */
  }
  return false;
}

export async function estimateUsage(): Promise<{ usage: number | null; quota: number | null }> {
  try {
    if (navigator.storage?.estimate) {
      const e = await navigator.storage.estimate();
      return { usage: e.usage ?? null, quota: e.quota ?? null };
    }
  } catch {
    /* ignore */
  }
  return { usage: null, quota: null };
}

export function newId(): string {
  const c = (globalThis as { crypto?: Crypto }).crypto;
  if (c && typeof c.randomUUID === 'function') return c.randomUUID();
  return 'id-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
}
