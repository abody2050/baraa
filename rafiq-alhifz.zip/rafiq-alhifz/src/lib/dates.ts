/** التواريخ المحلية بصيغة YYYY-MM-DD دون مشاكل المناطق الزمنية. */
const pad = (n: number) => String(n).padStart(2, '0');

export function toDateStr(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function parseDate(s: string): Date {
  const [y, m, d] = s.split('-').map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}

export const today = (): string => toDateStr(new Date());

export function addDays(s: string, n: number): string {
  const d = parseDate(s);
  d.setDate(d.getDate() + n);
  return toDateStr(d);
}

/** weekStart: 0 = الأحد ... 6 = السبت */
export function weekRange(s: string, weekStart: number): { from: string; to: string } {
  const d = parseDate(s);
  const back = (d.getDay() - weekStart + 7) % 7;
  const from = addDays(s, -back);
  return { from, to: addDays(from, 6) };
}

export function monthRange(s: string): { from: string; to: string } {
  const d = parseDate(s);
  const from = toDateStr(new Date(d.getFullYear(), d.getMonth(), 1));
  const to = toDateStr(new Date(d.getFullYear(), d.getMonth() + 1, 0));
  return { from, to };
}

export function isValidDateStr(s: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  return toDateStr(parseDate(s)) === s;
}

export function formatLong(s: string): string {
  try {
    return new Intl.DateTimeFormat('ar-u-nu-latn', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }).format(parseDate(s));
  } catch {
    return s;
  }
}

export function formatShort(s: string): string {
  try {
    return new Intl.DateTimeFormat('ar-u-nu-latn', { month: 'short', day: 'numeric' }).format(parseDate(s));
  } catch {
    return s;
  }
}
