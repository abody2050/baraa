import { DEFAULT_SETTINGS, DEFAULT_STANDARD, FONT_OPTIONS } from './defaults';
import type { Settings, Standard } from './types';
import { validateStandard } from './text';

const KEY = 'rafiq.settings';

const num = (v: unknown, d: number, min: number, max: number): number => {
  const n = typeof v === 'number' ? v : Number(v);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : d;
};
const color = (v: unknown, d: string): string => (typeof v === 'string' && /^#[0-9a-fA-F]{6}$/.test(v) ? v : d);

export function sanitizeStandard(v: unknown): Standard {
  if (v && typeof v === 'object') {
    const s = { ...DEFAULT_STANDARD, ...(v as Partial<Standard>) };
    if (validateStandard(s).length === 0) return s;
  }
  return { ...DEFAULT_STANDARD };
}

/** يدمج أي كائن مع الافتراضيات ويصحّح القيم غير المنطقية. */
export function sanitizeSettings(raw: unknown): Settings {
  const r = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  const d = DEFAULT_SETTINGS;
  const fonts = FONT_OPTIONS.map((f) => f.value);
  return {
    userName: typeof r.userName === 'string' && r.userName.trim() ? r.userName.trim().slice(0, 40) : d.userName,
    showName: typeof r.showName === 'boolean' ? r.showName : d.showName,
    theme: r.theme === 'dark' ? 'dark' : 'light',
    uiScale: num(r.uiScale, d.uiScale, 0.9, 1.3),
    previewFont: typeof r.previewFont === 'string' && fonts.includes(r.previewFont) ? r.previewFont : d.previewFont,
    previewFontSize: num(r.previewFontSize, d.previewFontSize, 12, 48),
    previewLineHeight: num(r.previewLineHeight, d.previewLineHeight, 1.3, 3),
    previewPageWidth: num(r.previewPageWidth, d.previewPageWidth, 280, 900),
    previewMargin: num(r.previewMargin, d.previewMargin, 8, 80),
    previewAlign: r.previewAlign === 'right' || r.previewAlign === 'center' ? r.previewAlign : 'justify',
    previewBg: color(r.previewBg, d.previewBg),
    previewColor: color(r.previewColor, d.previewColor),
    previewMode: r.previewMode === 'continuous' ? 'continuous' : 'single',
    quranPages: Math.round(num(r.quranPages, d.quranPages, 1, 2000)),
    weekStart: Math.round(num(r.weekStart, d.weekStart, 0, 6)),
    standard: sanitizeStandard(r.standard),
    lastBackup: typeof r.lastBackup === 'number' && Number.isFinite(r.lastBackup) ? r.lastBackup : null,
    backupReminderDays: Math.round(num(r.backupReminderDays, d.backupReminderDays, 0, 365)),
  };
}

export function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(KEY);
    return sanitizeSettings(raw ? JSON.parse(raw) : {});
  } catch {
    return sanitizeSettings({});
  }
}

export function saveSettings(s: Settings): boolean {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
    return true;
  } catch {
    return false;
  }
}
