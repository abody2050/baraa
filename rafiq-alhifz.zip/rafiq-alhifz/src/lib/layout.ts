import type { Standard } from './types';
import { tokenize } from './text';

export interface Face {
  number: number; // رقم الوجه ابتداءً من 1
  lines: string[]; // نصوص الأسطر (كل عنصر سطر مستقل)
  lineWords: string[][]; // كلمات كل سطر (للعرض بحاويات مستقلة)
  partial: boolean; // وجه غير مكتمل
}

export interface Layout {
  totalWords: number;
  totalLines: number;
  faces: Face[];
  warnings: string[];
}

/** يوزّع الكلمات على أسطر متوازنة دون حذف أو تكرار أو إعادة ترتيب. */
export function splitIntoLines(words: string[], std: Standard): { lines: string[][]; warnings: string[] } {
  const n = words.length;
  const warnings: string[] = [];
  if (n === 0) return { lines: [], warnings };

  const { minWordsPerLine: min, targetWordsPerLine: target, maxWordsPerLine: max } = std;
  const lo = Math.ceil(n / max);
  const hi = Math.floor(n / min);
  let k = Math.ceil(n / target);
  if (lo <= hi) k = Math.min(Math.max(k, lo), hi);
  k = Math.max(1, k);

  const base = Math.floor(n / k);
  const extra = n % k;
  const lines: string[][] = [];
  let pos = 0;
  for (let i = 0; i < k; i++) {
    const size = base + (i < extra ? 1 : 0);
    lines.push(words.slice(pos, pos + size));
    pos += size;
  }

  const outside = lines.filter((l) => l.length < min || l.length > max).length;
  if (outside > 0) {
    warnings.push(
      `بعض الأسطر (${outside}) تحتوي على أقل من ${min} كلمات أو أكثر من ${max} كلمة؛ حافظنا على جميع الكلمات ولم نحذف شيئًا.`,
    );
  }
  return { lines, warnings };
}

export function buildLayout(text: string, std: Standard): Layout {
  const words = tokenize(text);
  const { lines, warnings } = splitIntoLines(words, std);
  const faces: Face[] = [];
  for (let i = 0; i < lines.length; i += std.linesPerFace) {
    const chunk = lines.slice(i, i + std.linesPerFace);
    faces.push({
      number: faces.length + 1,
      lines: chunk.map((l) => l.join(' ')),
      lineWords: chunk,
      partial: chunk.length < std.linesPerFace,
    });
  }
  return { totalWords: words.length, totalLines: lines.length, faces, warnings };
}
