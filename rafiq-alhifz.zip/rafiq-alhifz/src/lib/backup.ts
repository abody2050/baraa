import type { BackupFile, Block, QuranEntry, Settings } from './types';
import { analyze, derive, validateStandard } from './text';
import { isValidDateStr } from './dates';
import { sanitizeSettings, sanitizeStandard } from './settings';

export function createBackup(settings: Settings, blocks: Block[], quran: QuranEntry[]): BackupFile {
  return { app: 'rafiq-alhifz', version: 1, exportedAt: Date.now(), settings, blocks, quran };
}

type Result = { ok: true; data: BackupFile } | { ok: false; error: string };

const isObj = (v: unknown): v is Record<string, unknown> => !!v && typeof v === 'object' && !Array.isArray(v);
const str = (v: unknown, d = ''): string => (typeof v === 'string' ? v : d);
const fin = (v: unknown, d = 0): number => (typeof v === 'number' && Number.isFinite(v) ? v : d);

/** يتحقق من النسخة الاحتياطية ويعيد بيانات منظَّفة. لا يغيّر أي نص أصلي. */
export function validateBackup(input: unknown, maxQuranPages = 2000): Result {
  if (!isObj(input)) return { ok: false, error: 'الملف ليس نسخة احتياطية صالحة.' };
  if (input.app !== 'rafiq-alhifz') return { ok: false, error: 'هذا الملف ليس من تطبيق «رفيق الحفظ».' };
  if (input.version !== 1) return { ok: false, error: 'إصدار النسخة الاحتياطية غير مدعوم.' };
  if (!Array.isArray(input.blocks) || !Array.isArray(input.quran)) return { ok: false, error: 'بنية النسخة الاحتياطية ناقصة.' };

  const settings = sanitizeSettings(input.settings);
  const blocks: Block[] = [];
  for (let i = 0; i < input.blocks.length; i++) {
    const b = input.blocks[i];
    if (!isObj(b) || typeof b.id !== 'string' || !b.id || typeof b.text !== 'string')
      return { ok: false, error: `السجل رقم ${i + 1} من الكتل تالف أو ناقص.` };
    const date = str(b.date);
    if (!isValidDateStr(date)) return { ok: false, error: `تاريخ الكتلة «${str(b.title, String(i + 1))}» غير صالح.` };
    const std = sanitizeStandard(b.standard);
    const a = analyze(b.text, std);
    const d = derive(a.words, std);
    blocks.push({
      id: b.id,
      title: str(b.title).slice(0, 200),
      category: str(b.category).slice(0, 40),
      text: b.text,
      date,
      createdAt: fin(b.createdAt, Date.now()),
      updatedAt: fin(b.updatedAt, Date.now()),
      words: a.words,
      chars: a.chars,
      lines: d.lines,
      faces: d.faces,
      notes: str(b.notes),
      standard: std,
    });
  }
  const quran: QuranEntry[] = [];
  for (let i = 0; i < input.quran.length; i++) {
    const q = input.quran[i];
    if (!isObj(q) || typeof q.id !== 'string' || !q.id) return { ok: false, error: `السجل رقم ${i + 1} من الحفظ القرآني تالف.` };
    const from = fin(q.fromPage), to = fin(q.toPage);
    if (!Number.isInteger(from) || !Number.isInteger(to) || from < 1 || to < from || to > maxQuranPages)
      return { ok: false, error: `نطاق الصفحات في سجل القرآن رقم ${i + 1} غير صالح.` };
    if (!isValidDateStr(str(q.date))) return { ok: false, error: `تاريخ سجل القرآن رقم ${i + 1} غير صالح.` };
    quran.push({ id: q.id, fromPage: from, toPage: to, pages: to - from + 1, date: str(q.date), notes: str(q.notes), createdAt: fin(q.createdAt, Date.now()) });
  }
  return { ok: true, data: { app: 'rafiq-alhifz', version: 1, exportedAt: fin(input.exportedAt, Date.now()), settings, blocks, quran } };
}

const blockKey = (b: Block) => `${b.date}|${b.title.trim()}|${b.text.trim()}`;
const quranKey = (q: QuranEntry) => `${q.date}|${q.fromPage}|${q.toPage}|${q.notes.trim()}`;

/** يدمج السجلات الواردة دون تكرار (بالمعرّف أو بالمحتوى نفسه). */
export function mergeImport(
  existingBlocks: Block[],
  existingQuran: QuranEntry[],
  incoming: BackupFile,
): { blocks: Block[]; quran: QuranEntry[]; addedBlocks: number; addedQuran: number; skipped: number } {
  const ids = new Set(existingBlocks.map((b) => b.id));
  const keys = new Set(existingBlocks.map(blockKey));
  const qids = new Set(existingQuran.map((q) => q.id));
  const qkeys = new Set(existingQuran.map(quranKey));
  const blocks: Block[] = [];
  const quran: QuranEntry[] = [];
  let skipped = 0;
  for (const b of incoming.blocks) {
    if (ids.has(b.id) || keys.has(blockKey(b))) { skipped++; continue; }
    ids.add(b.id); keys.add(blockKey(b)); blocks.push(b);
  }
  for (const q of incoming.quran) {
    if (qids.has(q.id) || qkeys.has(quranKey(q))) { skipped++; continue; }
    qids.add(q.id); qkeys.add(quranKey(q)); quran.push(q);
  }
  return { blocks, quran, addedBlocks: blocks.length, addedQuran: quran.length, skipped };
}

const csvCell = (v: string | number): string => {
  let s = String(v);
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // حماية من حقن المعادلات في Excel
  return '"' + s.replace(/"/g, '""') + '"';
};

export function toCsv(blocks: Block[], quran: QuranEntry[], std: Settings['standard']): string {
  const rows: (string | number)[][] = [['النوع', 'التاريخ', 'العنوان', 'التصنيف', 'الكلمات', 'الأحرف', 'الأسطر (تقديري)', 'الأوجه', 'ملاحظات']];
  const sorted = [...blocks].sort((a, b) => a.date.localeCompare(b.date) || a.createdAt - b.createdAt);
  for (const b of sorted) {
    const d = derive(b.words, std);
    rows.push(['نص', b.date, b.title, b.category, b.words, b.chars, d.lines, d.faces, b.notes]);
  }
  for (const q of [...quran].sort((a, b) => a.date.localeCompare(b.date))) {
    rows.push(['قرآن', q.date, `من صفحة ${q.fromPage} إلى ${q.toPage}`, 'قرآن', '', '', '', q.pages, q.notes]);
  }
  return '\uFEFF' + rows.map((r) => r.map(csvCell).join(',')).join('\r\n');
}

export function backupIsStale(lastBackup: number | null, days: number, hasData: boolean, now = Date.now()): boolean {
  if (!days || !hasData) return false;
  if (lastBackup === null) return true;
  return now - lastBackup > days * 86400000;
}

export { validateStandard };
