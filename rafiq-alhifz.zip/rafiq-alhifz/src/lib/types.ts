export interface Standard {
  linesPerFace: number;
  minWordsPerLine: number;
  targetWordsPerLine: number;
  maxWordsPerLine: number;
  wordsPerFace: number;
  facesPerJuz: number;
}

export type Theme = 'light' | 'dark';
export type Align = 'justify' | 'right' | 'center';
export type PreviewMode = 'single' | 'continuous';

export interface Settings {
  userName: string;
  showName: boolean;
  theme: Theme;
  uiScale: number; // نسبة حجم خط الواجهة (0.9 - 1.3)
  previewFont: string;
  previewFontSize: number; // px
  previewLineHeight: number; // نسبة من حجم الخط
  previewPageWidth: number; // px
  previewMargin: number; // px
  previewAlign: Align;
  previewBg: string;
  previewColor: string;
  previewMode: PreviewMode;
  quranPages: number;
  weekStart: number; // 0 = الأحد ... 6 = السبت
  standard: Standard;
  lastBackup: number | null;
  backupReminderDays: number; // 0 = بلا تذكير
}

export interface Block {
  id: string;
  title: string;
  category: string;
  text: string; // النص الأصلي كما أدخله المستخدم، دون أي تعديل
  date: string; // YYYY-MM-DD (تاريخ الحفظ)
  createdAt: number;
  updatedAt: number;
  words: number;
  chars: number;
  lines: number; // تقديري عند وقت التسجيل
  faces: number; // تقديري عند وقت التسجيل
  notes: string;
  standard: Standard; // المعيار المستخدم عند التسجيل
}

export interface QuranEntry {
  id: string;
  fromPage: number;
  toPage: number;
  pages: number;
  date: string;
  notes: string;
  createdAt: number;
}

export type StorageState = 'idle' | 'saving' | 'saved' | 'error' | 'unavailable';

export interface BackupFile {
  app: 'rafiq-alhifz';
  version: 1;
  exportedAt: number;
  settings: Settings;
  blocks: Block[];
  quran: QuranEntry[];
}
