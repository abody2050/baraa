/**
 * تصدير PDF بدون مكتبات خارجية:
 * كل صفحة تُرسم على Canvas (المتصفح يتولى وصل الحروف العربية واتجاه RTL بشكل صحيح)
 * ثم تُضمَّن كصورة JPEG داخل ملف PDF بسيط. الخط المستخدم هو خط الجهاز/الموقع المحلي.
 */
import type { Settings } from './types';
import type { Face } from './layout';

export interface PageImage { data: Uint8Array; w: number; h: number }

const enc = new TextEncoder();
const PAGE_W = 1050; // A5 تقريبًا بنسبة 148x210
const PAGE_H = 1485;
const PT_W = 420;
const PT_H = 595;

export function buildPdf(pages: PageImage[]): Uint8Array {
  const chunks: Uint8Array[] = [];
  const offsets: number[] = [];
  let length = 0;
  const push = (c: Uint8Array | string) => {
    const b = typeof c === 'string' ? enc.encode(c) : c;
    chunks.push(b);
    length += b.length;
  };
  const obj = (n: number, body: () => void) => {
    offsets[n] = length;
    push(`${n} 0 obj\n`);
    body();
    push('\nendobj\n');
  };
  push('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');
  // الأرقام: 1 الفهرس، 2 الصفحات، ثم لكل صفحة: صفحة، محتوى، صورة
  obj(1, () => push('<< /Type /Catalog /Pages 2 0 R >>'));
  const kids = pages.map((_, i) => `${3 + i * 3} 0 R`).join(' ');
  obj(2, () => push(`<< /Type /Pages /Kids [${kids}] /Count ${pages.length} >>`));
  pages.forEach((p, i) => {
    const pn = 3 + i * 3, cn = pn + 1, im = pn + 2;
    obj(pn, () =>
      push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PT_W} ${PT_H}] /Resources << /XObject << /Im0 ${im} 0 R >> >> /Contents ${cn} 0 R >>`),
    );
    const content = `q ${PT_W} 0 0 ${PT_H} 0 0 cm /Im0 Do Q`;
    obj(cn, () => push(`<< /Length ${content.length} >>\nstream\n${content}\nendstream`));
    obj(im, () => {
      push(`<< /Type /XObject /Subtype /Image /Width ${p.w} /Height ${p.h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${p.data.length} >>\nstream\n`);
      push(p.data);
      push('\nendstream');
    });
  });
  const total = 3 + pages.length * 3;
  const xref = length;
  let x = `xref\n0 ${total}\n0000000000 65535 f \n`;
  for (let n = 1; n < total; n++) x += String(offsets[n]).padStart(10, '0') + ' 00000 n \n';
  push(x);
  push(`trailer\n<< /Size ${total} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`);
  const out = new Uint8Array(length);
  let pos = 0;
  for (const c of chunks) { out.set(c, pos); pos += c.length; }
  return out;
}

function canvasToJpeg(canvas: HTMLCanvasElement): Promise<PageImage> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      async (blob) => {
        if (!blob) return reject(new Error('تعذر إنشاء صورة الصفحة.'));
        resolve({ data: new Uint8Array(await blob.arrayBuffer()), w: canvas.width, h: canvas.height });
      },
      'image/jpeg',
      0.92,
    );
  });
}

function newCanvas(bg: string): { c: HTMLCanvasElement; ctx: CanvasRenderingContext2D } {
  const c = document.createElement('canvas');
  c.width = PAGE_W;
  c.height = PAGE_H;
  const ctx = c.getContext('2d');
  if (!ctx) throw new Error('المتصفح لا يدعم الرسم على Canvas.');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, PAGE_W, PAGE_H);
  ctx.direction = 'rtl';
  ctx.textBaseline = 'middle';
  return { c, ctx };
}

async function ensureFonts(): Promise<void> {
  try { await document.fonts?.ready; } catch { /* ignore */ }
}

/** يرسم وجهًا واحدًا: كل سطر بكلماته المقسّمة مسبقًا، محاذاة RTL، دون التفاف تلقائي. */
export async function renderFace(face: Face, totalFaces: number, s: Settings): Promise<PageImage> {
  await ensureFonts();
  const { c, ctx } = newCanvas('#ffffff');
  const margin = 110;
  const innerW = PAGE_W - margin * 2;
  const top = 190;
  const bottom = PAGE_H - 170;
  const lines = s.standard.linesPerFace;
  const lineH = (bottom - top) / lines;

  // إطار
  ctx.strokeStyle = '#8a7a4a';
  ctx.lineWidth = 3;
  ctx.strokeRect(56, 56, PAGE_W - 112, PAGE_H - 112);

  // أكبر حجم خط يتسع لأطول سطر
  let size = Math.min(60, lineH * 0.7);
  const family = s.previewFont;
  const gapMin = 0.28;
  const fits = (px: number) => {
    ctx.font = `${px}px ${family}`;
    return face.lineWords.every((ws) => ws.reduce((a, w) => a + ctx.measureText(w).width, 0) + (ws.length - 1) * px * gapMin <= innerW);
  };
  while (size > 18 && !fits(size)) size -= 1;
  ctx.font = `${size}px ${family}`;
  ctx.fillStyle = '#111111';
  ctx.textAlign = 'right';

  face.lineWords.forEach((ws, i) => {
    const y = top + lineH * i + lineH / 2;
    const widths = ws.map((w) => ctx.measureText(w).width);
    const sum = widths.reduce((a, b) => a + b, 0);
    const justify = s.previewAlign === 'justify' && ws.length >= s.standard.minWordsPerLine;
    let gap = size * 0.32;
    if (justify && ws.length > 1) gap = (innerW - sum) / (ws.length - 1);
    let startX = PAGE_W - margin;
    if (s.previewAlign === 'center') startX = PAGE_W - margin - (innerW - (sum + gap * (ws.length - 1))) / 2;
    let x = startX;
    ws.forEach((w, k) => {
      ctx.fillText(w, x, y);
      x -= widths[k] + gap;
    });
  });

  // العنوان ورقم الصفحة خارج الأسطر الخمسة عشر
  ctx.textAlign = 'center';
  ctx.fillStyle = '#6b5d2f';
  ctx.font = `bold 40px ${family}`;
  ctx.fillText(`الوجه ${face.number}${face.partial ? ' (وجه جزئي: ' + face.lines.length + ' أسطر)' : ''}`, PAGE_W / 2, 125);
  ctx.font = `28px ${family}`;
  ctx.fillText(`${face.number} / ${totalFaces}`, PAGE_W / 2, PAGE_H - 100);
  return canvasToJpeg(c);
}

/** صفحات تقارير نصية (السجل اليومي والإحصائيات) مع التفاف يدوي للكلمات. */
export async function renderReport(title: string, rows: string[], s: Settings): Promise<PageImage[]> {
  await ensureFonts();
  const out: PageImage[] = [];
  const family = s.previewFont;
  const margin = 90;
  const innerW = PAGE_W - margin * 2;
  const lineH = 56;
  let cur = newCanvas('#ffffff');
  let y = 150;
  let pageNo = 1;
  const header = () => {
    cur.ctx.textAlign = 'center';
    cur.ctx.fillStyle = '#0f5c4d';
    cur.ctx.font = `bold 46px ${family}`;
    cur.ctx.fillText(title, PAGE_W / 2, 90);
    cur.ctx.textAlign = 'right';
    y = 170;
  };
  const footer = async () => {
    cur.ctx.textAlign = 'center';
    cur.ctx.fillStyle = '#666666';
    cur.ctx.font = `26px ${family}`;
    cur.ctx.fillText(String(pageNo), PAGE_W / 2, PAGE_H - 60);
    out.push(await canvasToJpeg(cur.c));
  };
  header();
  for (const row of rows) {
    const bold = row.startsWith('# ');
    const text = bold ? row.slice(2) : row;
    cur.ctx.font = `${bold ? 'bold ' : ''}34px ${family}`;
    // التفاف الكلمات
    const words = text.split(/\s+/).filter(Boolean);
    const lines: string[] = [];
    let line = '';
    for (const w of words) {
      const t = line ? line + ' ' + w : w;
      if (cur.ctx.measureText(t).width > innerW && line) { lines.push(line); line = w; } else line = t;
    }
    lines.push(line);
    if (words.length === 0) lines[0] = '';
    for (const l of lines) {
      if (y + lineH > PAGE_H - 120) {
        await footer();
        pageNo++;
        cur = newCanvas('#ffffff');
        header();
        cur.ctx.font = `${bold ? 'bold ' : ''}34px ${family}`;
      }
      cur.ctx.textAlign = 'right';
      cur.ctx.fillStyle = bold ? '#0f5c4d' : '#111111';
      cur.ctx.fillText(l, PAGE_W - margin, y + lineH / 2);
      y += lineH;
    }
  }
  await footer();
  return out;
}

export function downloadBytes(bytes: Uint8Array, filename: string, mime = 'application/pdf'): void {
  downloadBlob(new Blob([bytes as BlobPart], { type: mime }), filename);
}

export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
