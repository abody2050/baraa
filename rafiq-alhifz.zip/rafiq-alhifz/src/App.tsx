import { useEffect } from 'react';
import { usePath } from './router';
import { useStore } from './store';
import { Icon, Overlays, StorageBadge } from './components/ui';
import { Home } from './pages/Home';
import { AddPage } from './pages/AddPage';
import { Preview } from './pages/Preview';
import { BlockDetail } from './pages/BlockView';
import { EditBlock } from './pages/EditBlock';
import { History } from './pages/History';
import { Progress } from './pages/Progress';
import { Quran } from './pages/Quran';
import { Settings } from './pages/Settings';
import { Data } from './pages/Data';
import { Help } from './pages/Help';

function Routes({ path }: { path: string }) {
  const seg = path.split('/').filter(Boolean);
  switch (seg[0]) {
    case undefined: return <Home />;
    case 'add': return <AddPage />;
    case 'preview': return <Preview id={seg[1]} key={seg[1] ?? 'draft'} />;
    case 'block': return seg[1] ? <BlockDetail id={seg[1]} /> : <History />;
    case 'edit': return seg[1] ? <EditBlock id={seg[1]} /> : <History />;
    case 'history': return <History />;
    case 'progress': return <Progress />;
    case 'quran': return <Quran />;
    case 'settings': return <Settings />;
    case 'data': return <Data />;
    case 'help': return <Help />;
    default: return <Home />;
  }
}

const NAV = [
  { to: '/', label: 'الرئيسية', icon: 'home' },
  { to: '/history', label: 'السجل', icon: 'book' },
  { to: '/add', label: 'إضافة', icon: 'plus', fab: true },
  { to: '/progress', label: 'التقدم', icon: 'chart' },
  { to: '/settings', label: 'الإعدادات', icon: 'gear' },
];

export default function App() {
  const path = usePath();
  const { ready } = useStore();
  useEffect(() => { window.scrollTo({ top: 0 }); }, [path]);
  const active = (to: string) => (to === '/' ? path === '/' : path.startsWith(to));
  return (
    <div className="app">
      <StorageBadge />
      <main className="main" aria-busy={!ready}>
        <Routes path={path} />
      </main>
      <nav className="bottom-nav no-print" aria-label="التنقل الرئيسي">
        {NAV.map((n) => (
          <a key={n.to} href={'#' + n.to} className={(active(n.to) ? 'on ' : '') + (n.fab ? 'fab' : '')} aria-current={active(n.to) ? 'page' : undefined}>
            <Icon name={n.icon} size={n.fab ? 26 : 22} />
            <span>{n.label}</span>
          </a>
        ))}
      </nav>
      <Overlays />
    </div>
  );
}
