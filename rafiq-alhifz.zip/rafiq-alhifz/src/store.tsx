import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import type { Block, QuranEntry, Settings, StorageState } from './lib/types';
import { DEFAULT_SETTINGS } from './lib/defaults';
import { loadSettings, saveSettings, sanitizeSettings } from './lib/settings';
import { clearStores, getAll, newId, putItems, removeItem, requestPersistence } from './lib/db';
import { analyze, derive } from './lib/text';
import { mergeImport } from './lib/backup';
import type { BackupFile } from './lib/types';

export interface BlockInput {
  id?: string;
  title: string;
  category: string;
  text: string;
  date: string;
  notes: string;
}

interface Store {
  ready: boolean;
  blocks: Block[];
  quran: QuranEntry[];
  settings: Settings;
  status: StorageState;
  statusMessage: string;
  persisted: boolean;
  updateSettings: (patch: Partial<Settings>) => void;
  resetSettings: () => void;
  saveBlock: (input: BlockInput) => Promise<Block>;
  recalcBlock: (id: string) => Promise<void>;
  deleteBlock: (id: string) => Promise<void>;
  saveQuran: (e: Omit<QuranEntry, 'id' | 'createdAt' | 'pages'>) => Promise<void>;
  deleteQuran: (id: string) => Promise<void>;
  importBackup: (data: BackupFile) => Promise<{ addedBlocks: number; addedQuran: number; skipped: number }>;
  deleteAll: () => Promise<void>;
  markBackup: () => void;
}

const Ctx = createContext<Store | null>(null);
export const useStore = (): Store => {
  const v = useContext(Ctx);
  if (!v) throw new Error('Store غير متاح');
  return v;
};

const errMsg = (e: unknown) => (e instanceof Error ? e.message : 'حدث خطأ غير متوقع.');

export function StoreProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<Settings>(() => loadSettings());
  const [blocks, setBlocks] = useState<Block[]>([]);
  const [quran, setQuran] = useState<QuranEntry[]>([]);
  const [ready, setReady] = useState(false);
  const [status, setStatus] = useState<StorageState>('idle');
  const [statusMessage, setStatusMessage] = useState('');
  const [persisted, setPersisted] = useState(false);
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const timer = useRef<number | undefined>(undefined);

  // تحميل أولي من IndexedDB
  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const [b, q] = await Promise.all([getAll<Block>('blocks'), getAll<QuranEntry>('quran')]);
        if (!alive) return;
        setBlocks(b);
        setQuran(q);
        setPersisted(await requestPersistence());
      } catch (e) {
        if (!alive) return;
        setStatus('unavailable');
        setStatusMessage(errMsg(e));
      } finally {
        if (alive) setReady(true);
      }
    })();
    return () => { alive = false; };
  }, []);

  // المظهر والخط
  useEffect(() => {
    document.documentElement.dataset.theme = settings.theme;
    document.documentElement.style.setProperty('--ui-scale', String(settings.uiScale));
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', settings.theme === 'dark' ? '#0e1a17' : '#0f5c4d');
  }, [settings.theme, settings.uiScale]);

  const flash = useCallback((s: StorageState, msg = '') => {
    setStatus(s);
    setStatusMessage(msg);
    window.clearTimeout(timer.current);
    if (s === 'saved') timer.current = window.setTimeout(() => setStatus('idle'), 2500);
  }, []);

  const guarded = useCallback(
    async <T,>(fn: () => Promise<T>): Promise<T> => {
      flash('saving');
      try {
        const r = await fn();
        flash('saved');
        return r;
      } catch (e) {
        flash('error', errMsg(e));
        throw e;
      }
    },
    [flash],
  );

  const updateSettings = useCallback((patch: Partial<Settings>) => {
    const next = sanitizeSettings({ ...settingsRef.current, ...patch });
    setSettings(next);
    if (!saveSettings(next)) flash('error', 'تعذر حفظ الإعدادات في المتصفح.');
  }, [flash]);

  const resetSettings = useCallback(() => {
    const next = sanitizeSettings({ ...DEFAULT_SETTINGS, lastBackup: settingsRef.current.lastBackup });
    setSettings(next);
    saveSettings(next);
  }, []);

  const buildBlock = (input: BlockInput, existing?: Block): Block => {
    const std = settingsRef.current.standard;
    const a = analyze(input.text, std);
    const d = derive(a.words, std);
    const now = Date.now();
    return {
      id: input.id ?? existing?.id ?? newId(),
      title: input.title.trim() || 'بدون عنوان',
      category: input.category,
      text: input.text, // الأصل كما هو
      date: input.date,
      createdAt: existing?.createdAt ?? now,
      updatedAt: now,
      words: a.words,
      chars: a.chars,
      lines: d.lines,
      faces: d.faces,
      notes: input.notes,
      standard: { ...std },
    };
  };

  const saveBlock = useCallback(
    async (input: BlockInput) => {
      if (analyze(input.text, settingsRef.current.standard).words === 0) throw new Error('لا توجد كلمات لتسجيلها.');
      const existing = input.id ? blocksRef.current.find((b) => b.id === input.id) : undefined;
      const b = buildBlock(input, existing);
      await guarded(() => putItems('blocks', [b]));
      setBlocks((prev) => [...prev.filter((x) => x.id !== b.id), b]);
      return b;
    },
    [guarded],
  );
  const blocksRef = useRef<Block[]>(blocks);
  blocksRef.current = blocks;

  const recalcBlock = useCallback(
    async (id: string) => {
      const old = blocksRef.current.find((b) => b.id === id);
      if (!old) throw new Error('الكتلة غير موجودة.');
      const b = buildBlock({ id, title: old.title, category: old.category, text: old.text, date: old.date, notes: old.notes }, old);
      await guarded(() => putItems('blocks', [b]));
      setBlocks((prev) => prev.map((x) => (x.id === id ? b : x)));
    },
    [guarded],
  );

  const deleteBlock = useCallback(
    async (id: string) => {
      await guarded(() => removeItem('blocks', id));
      setBlocks((prev) => prev.filter((b) => b.id !== id));
    },
    [guarded],
  );

  const saveQuran = useCallback(
    async (e: Omit<QuranEntry, 'id' | 'createdAt' | 'pages'>) => {
      const entry: QuranEntry = { ...e, id: newId(), createdAt: Date.now(), pages: e.toPage - e.fromPage + 1 };
      await guarded(() => putItems('quran', [entry]));
      setQuran((prev) => [...prev, entry]);
    },
    [guarded],
  );

  const deleteQuran = useCallback(
    async (id: string) => {
      await guarded(() => removeItem('quran', id));
      setQuran((prev) => prev.filter((q) => q.id !== id));
    },
    [guarded],
  );

  const importBackup = useCallback(
    async (data: BackupFile) => {
      const m = mergeImport(blocksRef.current, quranRef.current, data);
      await guarded(async () => {
        if (m.blocks.length) await putItems('blocks', m.blocks);
        if (m.quran.length) await putItems('quran', m.quran);
      });
      setBlocks((prev) => [...prev, ...m.blocks]);
      setQuran((prev) => [...prev, ...m.quran]);
      return { addedBlocks: m.addedBlocks, addedQuran: m.addedQuran, skipped: m.skipped };
    },
    [guarded],
  );
  const quranRef = useRef<QuranEntry[]>(quran);
  quranRef.current = quran;

  const deleteAll = useCallback(async () => {
    await guarded(() => clearStores());
    setBlocks([]);
    setQuran([]);
  }, [guarded]);

  const markBackup = useCallback(() => updateSettings({ lastBackup: Date.now() }), [updateSettings]);

  const value = useMemo<Store>(
    () => ({ ready, blocks, quran, settings, status, statusMessage, persisted, updateSettings, resetSettings, saveBlock, recalcBlock, deleteBlock, saveQuran, deleteQuran, importBackup, deleteAll, markBackup }),
    [ready, blocks, quran, settings, status, statusMessage, persisted, updateSettings, resetSettings, saveBlock, recalcBlock, deleteBlock, saveQuran, deleteQuran, importBackup, deleteAll, markBackup],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}
